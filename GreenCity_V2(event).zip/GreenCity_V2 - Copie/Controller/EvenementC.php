<?php

require_once __DIR__ . '/../config_db.php';
require_once __DIR__ . '/../Model/evenement.php';

class EvenementController {
    private PDO $db;

    public function __construct() {
        try {
            $database = new Database();
            $this->db = $database->getConnection(); 
        } catch (Exception $e) {
            error_log("Erreur de connexion à la base de données: " . $e->getMessage());
            throw new Exception("Erreur de connexion à la base de données");
        }
    }

    // Create
    public function createEvenement(string $eventName, string $description, string $eventImage, string $eventType, ?string $eventDateE = null): bool {
        $sql = "INSERT INTO evenement (titre, description, image, type, dateE) 
                VALUES (:titre, :description, :image, :type, :dateE)";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':titre', $eventName);
        $stmt->bindParam(':description', $description);
        $stmt->bindParam(':image', $eventImage);
        $stmt->bindParam(':type', $eventType);
        $stmt->bindParam(':dateE', $eventDateE);
        
        return $stmt->execute();
    }

    // Read by ID
    public function getEvenementById($id) {
        try {
            $query = "SELECT * FROM evenement WHERE id = :id";
            $stmt = $this->db->prepare($query);
            $stmt->execute(['id' => $id]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($result) {
                return new Evenement(
                    $result['titre'],
                    $result['description'],
                    $result['image'],
                    $result['type'],
                    $result['id'],
                    $result['dateE'] ?? null
                );
            }
            return null;
        } catch (PDOException $e) {
            error_log("Erreur lors de la récupération de l'événement: " . $e->getMessage());
            return null;
        }
    }

    // Read all
    public function getAllEvenements(): array {
        $sql = "SELECT * FROM evenement";
        $stmt = $this->db->query($sql);
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $evenements = [];
        foreach ($result as $row) {
            $evenements[] = new Evenement(
                $row['titre'],
                $row['description'],
                $row['image'],
                $row['type'],
                $row['id'],
                $row['dateE'] ?? null
            );
        }
        return $evenements;
    }

    // Update
    public function updateEvenement(int $id, string $titre, string $description, string $image, string $type, ?string $dateE = null): bool {
        try {
            if ($id <= 0) {
                error_log("Erreur: ID d'événement invalide pour la mise à jour: $id");
                return false;
            }
            
            // Log the update attempt with all parameters
            error_log("Tentative de mise à jour de l'événement ID $id - Titre: $titre, Type: $type");
            
            // Check if event exists first
            $checkSql = "SELECT COUNT(*) FROM evenement WHERE id = :id";
            $checkStmt = $this->db->prepare($checkSql);
            $checkStmt->execute(['id' => $id]);
            $exists = (int)$checkStmt->fetchColumn() > 0;
            
            if (!$exists) {
                error_log("Tentative de mise à jour d'un événement inexistant, ID: $id");
                return false;
            }
            
            // Proceed with update
            $sql = "UPDATE evenement SET titre = :titre, description = :description, image = :image, type = :type, dateE = :dateE WHERE id = :id";
            $stmt = $this->db->prepare($sql);
            
            $params = [
                'id' => $id,
                'titre' => $titre,
                'description' => $description,
                'image' => $image,
                'type' => $type,
                'dateE' => $dateE
            ];
            
            error_log("Executing update for event ID $id");
            $result = $stmt->execute($params);
            
            if (!$result) {
                error_log("Échec de la mise à jour de l'événement ID $id: " . implode(', ', $stmt->errorInfo()));
            } else {
                error_log("Mise à jour réussie de l'événement ID $id");
            }
            
            return $result;
        } catch (PDOException $e) {
            error_log("Exception lors de la mise à jour de l'événement ID $id: " . $e->getMessage());
            return false;
        }
    }

    // Delete
    public function deleteEvenement(int $id): bool {
        try {
            $sql = "DELETE FROM evenement WHERE id = :id";
            $stmt = $this->db->prepare($sql);
            return $stmt->execute(['id' => $id]);
        } catch (PDOException $e) {
            error_log("Erreur lors de la suppression de l'événement: " . $e->getMessage());
            return false;
        }
    }

    // Get event stats by type
    public function getEventStatsByType(): array {
        try {
            $sql = "SELECT type, COUNT(*) as count FROM evenement GROUP BY type ORDER BY count DESC";
            $stmt = $this->db->query($sql);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Erreur lors de la récupération des statistiques: " . $e->getMessage());
            throw new Exception("Erreur lors de la récupération des statistiques");
        }
    }
}

// Traitement des requêtes
if (isset($_GET['action'])) {
    $controller = new EvenementController();

    // Action de suppression
    if ($_GET['action'] === 'delete' && isset($_GET['id'])) {
        $id = intval($_GET['id']);
        try {
            $success = $controller->deleteEvenement($id);
            
            if ($success) {
                header('Location: ../View/BackOffice/backoffice.php?success=1');
            } else {
                header('Location: ../View/BackOffice/backoffice.php?error=1');
            }
            exit();
        } catch (Exception $e) {
            error_log("Erreur lors de la suppression de l'événement ID $id: " . $e->getMessage());
            header('Location: ../View/BackOffice/backoffice.php?error=1');
            exit();
        }
    }
    
    // Action de récupération d'un événement
    if ($_GET['action'] === 'get' && isset($_GET['id'])) {
        header('Content-Type: application/json');
        $event = $controller->getEvenementById(intval($_GET['id']));
        
        if ($event) {
            echo json_encode([
                'status' => 'success',
                'data' => [
                    'id' => $event->getId(),
                    'titre' => $event->getTitre(),
                    'description' => $event->getDescription(),
                    'image' => $event->getImage(),
                    'type' => $event->getType(),
                    'dateE' => $event->getDateE()
                ]
            ]);
        } else {
            echo json_encode([
                'status' => 'error',
                'message' => 'Événement non trouvé'
            ]);
        }
        exit;
    }
}

?>
