<?php


require_once __DIR__ . '/../config_db.php';
require_once __DIR__ . '/../Model/Reservation.php';
require_once __DIR__ . '/ReservationMailer.php';

class ReservationController {
    private PDO $db;
    private $mailer;

    public function __construct() {
        try {
            $database = new Database();
            $this->db = $database->getConnection(); 
            $this->mailer = new ReservationMailer();
        } catch (Exception $e) {
            error_log("Erreur de connexion à la base de données: " . $e->getMessage());
            throw new Exception("Erreur de connexion à la base de données");
        }
    }

    // Create
    public function createReservation($data) {
        try {
            $query = "INSERT INTO reservation (fullname, email, date, participants, allergies, evenement_id, statut) 
                      VALUES (:fullname, :email, :date, :participants, :allergies, :evenement_id, 'en_attente')";
            
            $stmt = $this->db->prepare($query);
            $success = $stmt->execute([
                'fullname' => $data['fullname'],
                'email' => $data['email'],
                'date' => $data['date'],
                'participants' => $data['participants'],
                'allergies' => $data['allergies'],
                'evenement_id' => $data['evenement_id']
            ]);

            if ($success) {
                $reservationId = $this->db->lastInsertId();
                
                // Send confirmation email
                $data['id'] = $reservationId;
                $data['statut'] = 'en_attente';
                $emailSent = $this->mailer->sendReservationConfirmation($data);
                
                if (!$emailSent) {
                    error_log("Erreur lors de l'envoi de l'email de confirmation pour la réservation ID $reservationId");
                }
                
                return [
                    'status' => 'success',
                    'message' => 'Réservation créée avec succès',
                    'reservation_id' => $reservationId,
                    'email_sent' => $emailSent
                ];
            } else {
                return [
                    'status' => 'error',
                    'message' => 'Erreur lors de la création de la réservation'
                ];
            }
        } catch (PDOException $e) {
            return [
                'status' => 'error',
                'message' => 'Erreur lors de la création de la réservation: ' . $e->getMessage()
            ];
        }
    }

    // Read by ID
    public function getReservationById(int $id): ?Reservation {
        $sql = "SELECT * FROM reservation WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        $result = $stmt->fetch();

        if ($result) {
            return new Reservation(
                $result['id'],
                $result['fullname'],
                $result['email'],
                $result['date'],
                $result['participants'],
                $result['allergies'],
                $result['evenement_id']
            );
        }
        return null;
    }

    // Read all
    public function getAllReservations(): array {
        $sql = "SELECT * FROM reservation";
        $stmt = $this->db->query($sql);
        $result = $stmt->fetchAll();

        $reservations = [];
        foreach ($result as $row) {
            $reservations[] = new Reservation(
                $row['id'],
                $row['fullname'],
                $row['email'],
                $row['date'],
                $row['participants'],
                $row['allergies'],
                $row['evenement_id']
            );
        }
        return $reservations;
    }

    // Read by Evenement
    public function getReservationsByEvenement(int $evenement_id): array {
        try {
        $sql = "SELECT * FROM reservation WHERE evenement_id = :evenement_id";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':evenement_id', $evenement_id);
        $stmt->execute();
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $reservations = [];
        foreach ($result as $row) {
                $reservations[] = [
                    'id' => (int)$row['id'],
                    'fullname' => $row['fullname'],
                    'email' => $row['email'],
                    'date' => $row['date'],
                    'participants' => (int)$row['participants'],
                    'allergies' => $row['allergies'],
                    'evenement_id' => (int)$row['evenement_id'],
                    'statut' => $row['statut']
                ];
            }
            return $reservations;
        } catch (PDOException $e) {
            error_log("Erreur lors de la récupération des réservations: " . $e->getMessage());
            throw new Exception("Erreur lors de la récupération des réservations");
        }
    }

    // Delete
    public function deleteReservation(int $id): bool {
        $sql = "DELETE FROM reservation WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    public function updateReservation(int $id, string $fullname, string $email, string $date, int $participants, string $allergies, int $evenement_id, string $statut = null): bool {
        $sql = "UPDATE reservation 
                SET fullname = :fullname, 
                    email = :email, 
                    date = :date, 
                    participants = :participants, 
                    allergies = :allergies, 
                    evenement_id = :evenement_id";
        
        if ($statut !== null) {
            $sql .= ", statut = :statut";
        }
        
        $sql .= " WHERE id = :id";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':fullname', $fullname);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':date', $date);
        $stmt->bindParam(':participants', $participants);
        $stmt->bindParam(':allergies', $allergies);
        $stmt->bindParam(':evenement_id', $evenement_id);
        
        if ($statut !== null) {
            $stmt->bindParam(':statut', $statut);
        }
        
        return $stmt->execute();
    }

    // Nouvelle méthode pour mettre à jour uniquement le statut
    public function updateReservationStatus(int $id, string $statut): bool {
        try {
            $sql = "UPDATE reservation SET statut = :statut WHERE id = :id";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':id', $id);
            $stmt->bindParam(':statut', $statut);
            $success = $stmt->execute();
            
            if ($success) {
                // Get full reservation data to send email
                $reservation = $this->getReservationById($id);
                if ($reservation) {
                    $reservationData = [
                        'id' => $reservation->getId(),
                        'fullname' => $reservation->getFullname(),
                        'email' => $reservation->getEmail(),
                        'date' => $reservation->getDate(),
                        'participants' => $reservation->getParticipants(),
                        'allergies' => $reservation->getAllergies(),
                        'evenement_id' => $reservation->getEvenementId(),
                        'statut' => $statut
                    ];
                    
                    // Send status update email
                    $this->mailer->sendStatusUpdateEmail($reservationData);
                }
            }
            
            return $success;
        } catch (PDOException $e) {
            error_log("Erreur lors de la mise à jour du statut de la réservation: " . $e->getMessage());
            return false;
        }
    }

    // Get reservations with event details using JOIN
    public function getReservationsWithEventDetails(): array {
        $sql = "SELECT r.*, e.titre as event_titre, e.description as event_description, 
                       e.image as event_image, e.type as event_type 
                FROM reservation r 
                LEFT JOIN evenement e ON r.evenement_id = e.id";
        
        $stmt = $this->db->query($sql);
        $result = $stmt->fetchAll();

        $reservationsWithEvents = [];
        foreach ($result as $row) {
            $reservation = new Reservation(
                $row['id'],
                $row['fullname'],
                $row['email'],
                $row['date'],
                $row['participants'],
                $row['allergies'],
                $row['evenement_id']
            );

            // Add event details as a property to the reservation object
            $reservation->setEventDetails([
                'titre' => $row['event_titre'],
                'description' => $row['event_description'],
                'image' => $row['event_image'],
                'type' => $row['event_type']
            ]);

            $reservationsWithEvents[] = $reservation;
        }

        return $reservationsWithEvents;
    }

    // Get reservations count by event
    public function getReservationsCountByEvent(): array {
        $sql = "SELECT e.id, e.titre, COUNT(r.id) as reservation_count 
                FROM evenement e 
                LEFT JOIN reservation r ON e.id = r.evenement_id 
                GROUP BY e.id, e.titre";
        
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

}

// Gérer la requête POST pour la création de réservation
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    
    try {
        // Log des données brutes reçues
        $rawData = file_get_contents('php://input');
        error_log("Données brutes reçues: " . $rawData);
        
        $data = json_decode($rawData, true);
        
        if (!$data) {
            throw new Exception('Données invalides: ' . json_last_error_msg());
        }
        
        error_log("Données décodées: " . print_r($data, true));
        
        // Validation des données requises
        $requiredFields = ['fullname', 'email', 'date', 'participants', 'evenement_id'];
        foreach ($requiredFields as $field) {
            if (!isset($data[$field]) || empty($data[$field])) {
                throw new Exception("Le champ '$field' est requis");
            }
        }

        // Validation du format de l'email
        if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            throw new Exception("Format d'email invalide");
        }
        
        // Validation du nombre de participants
        if (!is_numeric($data['participants']) || $data['participants'] < 1) {
            throw new Exception("Le nombre de participants doit être un nombre positif");
        }

        // Création de la réservation
        $controller = new ReservationController();
        $result = $controller->createReservation([
            'fullname' => $data['fullname'],
            'email' => $data['email'],
            'date' => $data['date'],
            'participants' => (int)$data['participants'],
            'allergies' => $data['allergies'] ?? '',
            'evenement_id' => (int)$data['evenement_id']
        ]);
        
        echo json_encode($result);
        
    } catch (Exception $e) {
        echo json_encode([
            'status' => 'error',
            'message' => $e->getMessage()
        ]);
    }
    exit;
}

// Gérer la requête GET pour récupérer les réservations
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    header('Content-Type: application/json');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');
    
    try {
        $controller = new ReservationController();
        
        if (isset($_GET['id'])) {
            $reservation = $controller->getReservationById((int)$_GET['id']);
            if ($reservation) {
                echo json_encode([
                    'status' => 'success',
                    'data' => $reservation->toArray()
                ]);
            } else {
                throw new Exception('Réservation non trouvée');
            }
        } elseif (isset($_GET['evenement_id'])) {
            $reservations = $controller->getReservationsByEvenement((int)$_GET['evenement_id']);
            echo json_encode([
                'status' => 'success',
                'data' => $reservations
            ]);
        } elseif (isset($_GET['with_events'])) {
            $reservations = $controller->getReservationsWithEventDetails();
            echo json_encode([
                'status' => 'success',
                'data' => $reservations
            ]);
        } elseif (isset($_GET['count_by_event'])) {
            $counts = $controller->getReservationsCountByEvent();
            echo json_encode([
                'status' => 'success',
                'data' => $counts
            ]);
        } else {
            $reservations = $controller->getAllReservations();
            $reservationsArray = array_map(function($reservation) {
                return $reservation->toArray();
            }, $reservations);
            echo json_encode([
                'status' => 'success',
                'data' => $reservationsArray
            ]);
        }
    } catch (Exception $e) {
        error_log("Erreur lors de la récupération des réservations: " . $e->getMessage());
        http_response_code(400);
        echo json_encode([
            'status' => 'error',
            'message' => $e->getMessage()
        ]);
    }
    exit;
}

// Handling PUT requests (for updating reservation status)
if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    header('Content-Type: application/json');
    
    try {
        $rawData = file_get_contents('php://input');
        $data = json_decode($rawData, true);
        
        if (!$data) {
            throw new Exception('Données invalides: ' . json_last_error_msg());
        }
        
        if (!isset($data['id']) || !isset($data['statut'])) {
            throw new Exception('ID de réservation et statut requis');
        }
        
        $id = (int)$data['id'];
        $statut = $data['statut'];
        
        // Validate status value
        $validStatuses = ['en_attente', 'confirmé', 'annulé'];
        if (!in_array($statut, $validStatuses)) {
            throw new Exception('Statut invalide. Statuts valides: ' . implode(', ', $validStatuses));
        }
        
        $controller = new ReservationController();
        $success = $controller->updateReservationStatus($id, $statut);
        
        if ($success) {
            echo json_encode([
                'status' => 'success',
                'message' => 'Statut de la réservation mis à jour avec succès',
                'email_sent' => true
            ]);
        } else {
            echo json_encode([
                'status' => 'error',
                'message' => 'Erreur lors de la mise à jour du statut'
            ]);
        }
    } catch (Exception $e) {
        echo json_encode([
            'status' => 'error',
            'message' => $e->getMessage()
        ]);
    }
    exit;
}

// Gérer la requête DELETE pour supprimer une réservation
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    header('Content-Type: application/json');
    
    try {
        if (!isset($_GET['id'])) {
            throw new Exception('ID de réservation manquant');
        }
        
        $controller = new ReservationController();
        $success = $controller->deleteReservation((int)$_GET['id']);
        
        if ($success) {
            echo json_encode([
                'status' => 'success',
                'message' => 'Réservation supprimée avec succès'
            ]);
        } else {
            throw new Exception('Erreur lors de la suppression de la réservation');
        }
        
    } catch (Exception $e) {
        http_response_code(400);
        echo json_encode([
            'status' => 'error',
            'message' => $e->getMessage()
        ]);
    }
    exit;
}

// Si la méthode HTTP n'est pas supportée
header('Content-Type: application/json');
http_response_code(405);
echo json_encode([
    'status' => 'error',
    'message' => 'Méthode non autorisée'
]);
exit;

?>
