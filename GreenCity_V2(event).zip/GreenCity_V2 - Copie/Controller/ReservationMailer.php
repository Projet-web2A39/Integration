<?php
require_once __DIR__ . '/../View/send.php';
require_once __DIR__ . '/EvenementC.php';

class ReservationMailer {
    private $evenementController;

    public function __construct() {
        $this->evenementController = new EvenementController();
    }

    /**
     * Send confirmation email when a reservation is created
     * 
     * @param array $reservationData The reservation data
     * @return bool Whether the email was sent successfully
     */
    public function sendReservationConfirmation($reservationData) {
        // Get event details
        $evenement = $this->evenementController->getEvenementById($reservationData['evenement_id']);
        
        if (!$evenement) {
            error_log("Erreur: Événement non trouvé pour l'ID {$reservationData['evenement_id']}");
            return false;
        }

        // Format date
        $formattedDate = date('d/m/Y', strtotime($reservationData['date']));
        
        // Build email subject
        $subject = "Confirmation de réservation - {$evenement->getTitre()}";
        
        // Build email body (HTML)
        $body = "
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background-color: #2e7d32; color: white; padding: 15px; text-align: center; }
                .content { padding: 20px; border: 1px solid #ddd; }
                .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #666; }
                .event-details { background-color: #f9f9f9; padding: 15px; margin: 15px 0; border-left: 4px solid #2e7d32; }
                .reservation-details { margin: 15px 0; }
                .button { display: inline-block; background-color: #2e7d32; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1>Confirmation de Réservation</h1>
                </div>
                <div class='content'>
                    <p>Bonjour <strong>{$reservationData['fullname']}</strong>,</p>
                    
                    <p>Nous vous remercions pour votre réservation à l'événement <strong>{$evenement->getTitre()}</strong>.</p>
                    
                    <div class='event-details'>
                        <h2>Détails de l'Événement</h2>
                        <p><strong>Événement:</strong> {$evenement->getTitre()}</p>
                        <p><strong>Type:</strong> {$evenement->getType()}</p>
                        <p><strong>Description:</strong> {$evenement->getDescription()}</p>
                    </div>
                    
                    <div class='reservation-details'>
                        <h2>Détails de votre Réservation</h2>
                        <p><strong>Nom et prénom:</strong> {$reservationData['fullname']}</p>
                        <p><strong>Date:</strong> {$formattedDate}</p>
                        <p><strong>Nombre de participants:</strong> {$reservationData['participants']}</p>";
        
        // Add allergies info if provided
        if (!empty($reservationData['allergies'])) {
            $body .= "<p><strong>Allergies/Besoins spécifiques:</strong> {$reservationData['allergies']}</p>";
        }
        
        // Add reservation status
        $body .= "<p><strong>Statut:</strong> En attente de confirmation</p>
                    </div>
                    
                    <p>Un membre de notre équipe examinera votre réservation et vous enverra une confirmation définitive prochainement.</p>
                    
                    <p>Si vous avez des questions, n'hésitez pas à nous contacter à l'adresse <a href='mailto:kasrfaset@gmail.com'>kasrfaset@gmail.com</a>.</p>
                    
                    <p>Merci de contribuer à un avenir plus vert avec Green City !</p>
                </div>
                <div class='footer'>
                    <p>© 2025 Green City - Tous droits réservés</p>
                </div>
            </div>
        </body>
        </html>
        ";
        
        // Send the email using the send function from send.php
        return send($reservationData['email'], $subject, $body);
    }
    
    /**
     * Send status update email when a reservation status changes
     * 
     * @param array $reservationData The reservation data including the new status
     * @return bool Whether the email was sent successfully
     */
    public function sendStatusUpdateEmail($reservationData) {
        // Get event details
        $evenement = $this->evenementController->getEvenementById($reservationData['evenement_id']);
        
        if (!$evenement) {
            error_log("Erreur: Événement non trouvé pour l'ID {$reservationData['evenement_id']}");
            return false;
        }

        // Format date
        $formattedDate = date('d/m/Y', strtotime($reservationData['date']));
        
        // Format status for display
        $statusDisplay = [
            'en_attente' => 'En attente',
            'confirmé' => 'Confirmée',
            'annulé' => 'Annulée'
        ];
        
        $displayStatus = isset($statusDisplay[$reservationData['statut']]) ? 
                        $statusDisplay[$reservationData['statut']] : 
                        $reservationData['statut'];
        
        // Build email subject based on status
        $subject = "Mise à jour de votre réservation - {$evenement->getTitre()}";
        
        // Set status-specific content
        $statusMessage = '';
        $buttonColor = '#2e7d32';
        
        if ($reservationData['statut'] === 'confirmé') {
            $statusMessage = "<p>Nous sommes heureux de vous informer que votre réservation pour l'événement <strong>{$evenement->getTitre()}</strong> a été <strong style='color: #2e7d32;'>confirmée</strong> !</p>";
            $buttonColor = '#2e7d32';
        } elseif ($reservationData['statut'] === 'annulé') {
            $statusMessage = "<p>Nous sommes désolés de vous informer que votre réservation pour l'événement <strong>{$evenement->getTitre()}</strong> a été <strong style='color: #e74c3c;'>annulée</strong>.</p>";
            $buttonColor = '#e74c3c';
        }
        
        // Build email body (HTML)
        $body = "
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background-color: {$buttonColor}; color: white; padding: 15px; text-align: center; }
                .content { padding: 20px; border: 1px solid #ddd; }
                .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #666; }
                .event-details { background-color: #f9f9f9; padding: 15px; margin: 15px 0; border-left: 4px solid {$buttonColor}; }
                .reservation-details { margin: 15px 0; }
                .button { display: inline-block; background-color: {$buttonColor}; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1>Mise à jour de Réservation</h1>
                </div>
                <div class='content'>
                    <p>Bonjour <strong>{$reservationData['fullname']}</strong>,</p>
                    
                    {$statusMessage}
                    
                    <div class='event-details'>
                        <h2>Détails de l'Événement</h2>
                        <p><strong>Événement:</strong> {$evenement->getTitre()}</p>
                        <p><strong>Type:</strong> {$evenement->getType()}</p>
                        <p><strong>Description:</strong> {$evenement->getDescription()}</p>
                    </div>
                    
                    <div class='reservation-details'>
                        <h2>Détails de votre Réservation</h2>
                        <p><strong>Nom et prénom:</strong> {$reservationData['fullname']}</p>
                        <p><strong>Date:</strong> {$formattedDate}</p>
                        <p><strong>Nombre de participants:</strong> {$reservationData['participants']}</p>";
        
        // Add allergies info if provided
        if (!empty($reservationData['allergies'])) {
            $body .= "<p><strong>Allergies/Besoins spécifiques:</strong> {$reservationData['allergies']}</p>";
        }
        
        // Add reservation status
        $body .= "<p><strong>Statut:</strong> {$displayStatus}</p>
                    </div>";
                    
        // Add specific message based on status
        if ($reservationData['statut'] === 'confirmé') {
            $body .= "<p>Nous sommes impatients de vous accueillir à cet événement !</p>";
        } elseif ($reservationData['statut'] === 'annulé') {
            $body .= "<p>Si vous avez des questions concernant cette annulation, n'hésitez pas à nous contacter.</p>";
        }
        
        $body .= "
                    <p>Pour toute question, contactez-nous à <a href='mailto:kasrfaset@gmail.com'>kasrfaset@gmail.com</a>.</p>
                    
                    <p>Merci de contribuer à un avenir plus vert avec Green City !</p>
                </div>
                <div class='footer'>
                    <p>© 2025 Green City - Tous droits réservés</p>
                </div>
            </div>
        </body>
        </html>
        ";
        
        // Send the email using the send function from send.php
        return send($reservationData['email'], $subject, $body);
    }
}
?> 