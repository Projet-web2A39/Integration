<?php
class Reservation {
    private int $id;
    private string $fullname;
    private string $email;
    private string $date;
    private int $participants;
    private string $allergies;
    private int $evenement_id;
    private string $statut;
    private $event_details = null; // For storing event details when fetched with JOIN

    public function __construct(int $id, string $fullname, string $email, string $date, int $participants, string $allergies, int $evenement_id, string $statut = 'en_attente') {
        $this->id = $id;
        $this->fullname = $fullname;
        $this->email = $email;
        $this->date = $date;
        $this->participants = $participants;
        $this->allergies = $allergies;
        $this->evenement_id = $evenement_id;
        $this->statut = $statut;
    }

    // Getters
    public function getId(): int {
        return $this->id;
    }

    public function getFullname(): string {
        return $this->fullname;
    }

    public function getEmail(): string {
        return $this->email;
    }

    public function getDate(): string {
        return $this->date;
    }

    public function getParticipants(): int {
        return $this->participants;
    }

    public function getAllergies(): string {
        return $this->allergies;
    }

    public function getEvenementId(): int {
        return $this->evenement_id;
    }

    public function getStatut(): string {
        return $this->statut;
    }

    public function getEventDetails() {
        return $this->event_details;
    }

    // Setters
    public function setFullname(string $fullname): void {
        $this->fullname = $fullname;
    }

    public function setEmail(string $email): void {
        $this->email = $email;
    }

    public function setDate(string $date): void {
        $this->date = $date;
    }

    public function setParticipants(int $participants): void {
        $this->participants = $participants;
    }

    public function setAllergies(string $allergies): void {
        $this->allergies = $allergies;
    }

    public function setEvenementId(int $evenement_id): void {
        $this->evenement_id = $evenement_id;
    }

    public function setStatut(string $statut): void {
        $this->statut = $statut;
    }

    public function setEventDetails($details): void {
        $this->event_details = $details;
    }

    // Méthode pour convertir l'objet en tableau
    public function toArray(): array {
        $data = [
            'id' => $this->id,
            'fullname' => $this->fullname,
            'email' => $this->email,
            'date' => $this->date,
            'participants' => $this->participants,
            'allergies' => $this->allergies,
            'evenement_id' => $this->evenement_id,
            'statut' => $this->statut
        ];
        
        if ($this->event_details !== null) {
            $data['event_details'] = $this->event_details;
        }
        
        return $data;
    }
}
?>
