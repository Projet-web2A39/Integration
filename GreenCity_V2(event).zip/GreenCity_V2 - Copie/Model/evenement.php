<?php
class Evenement {
    private ?int $id;
    private string $titre;
    private string $description;
    private string $image;
    private string $type;
    private ?string $dateE;

    public function __construct(string $titre, string $description, string $image, string $type, ?int $id = null, ?string $dateE = null) {
        $this->id = $id;
        $this->titre = $titre;
        $this->description = $description;
        $this->image = $image;
        $this->type = $type;
        $this->dateE = $dateE;
    }

    public function getId(): ?int {
        return $this->id;
    }

    public function setId(int $id): void {
        $this->id = $id;
    }

    public function getTitre(): string {
        return $this->titre;
    }

    public function setTitre(string $titre): void {
        $this->titre = $titre;
    }

    public function getDescription(): string {
        return $this->description;
    }

    public function setDescription(string $description): void {
        $this->description = $description;
    }

    public function getImage(): string {
        return $this->image;
    }

    public function setImage(string $image): void {
        $this->image = $image;
    }

    public function getType(): string {
        return $this->type;
    }

    public function setType(string $type): void {
        $this->type = $type;
    }
    
    public function getDateE(): ?string {
        return $this->dateE;
    }
    
    public function setDateE(?string $dateE): void {
        $this->dateE = $dateE;
    }
}
?>
