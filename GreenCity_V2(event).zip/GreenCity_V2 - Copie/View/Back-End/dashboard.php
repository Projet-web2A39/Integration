<?php
require "user_back.php";
require "forum_back.php";
require "events_back.php";
require "defi_back.php";

// Activer l'affichage des erreurs pour le débogage
error_reporting(E_ALL);
ini_set('display_errors', 1);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Green City - Dashboard</title>
    <link rel="stylesheet" href="back.css">
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <img src="../../Ressources/logo_GreenCity_trans.png" width="80%" alt="GreenCity Logo">
        </div>
        <nav class="sidebar-nav">
            <a href="../Front-End/interface.php" class="nav-item">Home</a>
            <a href="../event/events.php" class="nav-item active">Events</a>
            <a href="../Front-End/forum.php" class="nav-item">Forum</a>
            <a href="#" class="nav-item">Challenges</a>
            <a href="../map/map.php" class="nav-item">Map</a>
            <a href="dashboard.php" class="nav-item">Dashboard</a>
        </nav>
    </aside>

    <!-- Main Content -->
    <div class="main-content">
        <header class="main-header">
            <h1>Dashboard</h1>
            <div class="header-actions">
                
                <a href="modify_profile.php" class="profile-link">
                    <img src="../../<?= $userInfo['Img'] ?? 'Ressources/profile.png' ?>" alt="Profile Icon" class="profile-icon">
                    <h2> <?= $userInfo['Prenom'] . " " . $userInfo['Nom'] ?></h2>
                </a>
            </div>
        </header>
        <section class="dashboard-hero">
            <div class="dashboard-overlay">
                <div class="dashboard-content">
                    <h2>Welcome to Your GreenCity Dashboard!</h2>
                    <p>Track your eco-friendly activities, events, and contributions to a greener future.</p>
                </div>
            </div>
        </section>



<!-- -------------------------------------------------------------------------------------------------------------------------------------- -->



        <!-- Utilisateurs -->
        <div class="dashboard-panels">
            <div class="panel forum-admin">
                <h3>Utilisateurs GreenCity</h3>
                <form method="GET" action="dashboard.php" class="search-form">
                    <input type="text" name="user_search" class="search-input" placeholder="Rechercher un utilisateur (Id, Nom, Prenom)" value="<?= htmlspecialchars($userSearch) ?>" />
                    <button type="submit" class="search-button">Rechercher</button>
                    <select name="user_sort_by" class="sort-select">
                        <option value="Id" <?= $userSortBy == 'Id' ? 'selected' : '' ?>>Par ID</option>
                        <option value="Nom" <?= $userSortBy == 'Nom' ? 'selected' : '' ?>>Par Nom</option>
                        <option value="Prenom" <?= $userSortBy == 'Prenom' ? 'selected' : '' ?>>Par Prénom</option>
                        <option value="Mail" <?= $userSortBy == 'Mail' ? 'selected' : '' ?>>Par Mail</option>
                        <option value="Role" <?= $userSortBy == 'Role' ? 'selected' : '' ?>>Par Rôle</option>
                    </select>
                    <button type="submit" class="sort-button">Trier</button>
                    <input type="hidden" name="search" value="<?= htmlspecialchars($search) ?>">
                    <input type="hidden" name="sort_by" value="<?= htmlspecialchars($sortBy) ?>">
                    <input type="hidden" name="selected_topic" value="<?= htmlspecialchars($selectedTopic ?? '') ?>">
                </form>
                <table class="forum-table">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Nom</th>
                            <th>Prénom</th>
                            <th>Mail</th>
                            <th>Rôle</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($allUsers as $row): ?>
                            <tr>
                                <td><?= htmlspecialchars($row['Id']) ?></td>
                                <td><?= htmlspecialchars($row['Nom']) ?></td>
                                <td><?= htmlspecialchars($row['Prenom']) ?></td>
                                <td><?= htmlspecialchars($row['Mail']) ?></td>
                                <td><?= htmlspecialchars($row['Role']) ?></td>
                                <td>
                                    <?php if ($row['Role'] != "Admin"): ?>
                                        <?php if ($row['Status'] == "En Attente"): ?>
                                            <form method="post" style="display:inline;">
                                                <input type="hidden" name="confirm" value="<?= $row['Id'] ?>">
                                                <button type="submit" class="action-btn confirm">Confirmer</button>
                                            </form>
                                        <?php else: ?>
                                            <form method="post" style="display:inline;">
                                                <input type="hidden" name="defin_admin" value="<?= $row['Id'] ?>">
                                                <button type="submit" class="action-btn edit">Définir Admin</button>
                                            </form>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <form method="post" style="display:inline;">
                                            <input type="hidden" name="remove_admin" value="<?= $row['Id'] ?>">
                                            <button type="submit" class="action-btn delete">Supprimer des Admins</button>
                                        </form>
                                    <?php endif; ?>
                                    <form method="post" style="display:inline;">
                                        <input type="hidden" name="delete_id" value="<?= $row['Id'] ?>">
                                        <button type="submit" class="action-btn delete">Supprimer</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>






<!-- -------------------------------------------------------------------------------------------------------------------------------------- -->






        <!-- Forums -->
        <div class="dashboard-panels">
            <div class="panel forum-admin">
                <h3>Management of Topics and Comments</h3>
                <form method="GET" action="dashboard.php" class="search-form">
                    <input type="text" name="search" class="search-input" placeholder="Rechercher par nom de client" value="<?= htmlspecialchars($search) ?>" />
                    <button type="submit" class="search-button">Rechercher</button>
                    <select name="sort_by" class="sort-select">
                        <option value="created_at" <?= $sortBy == 'created_at' ? 'selected' : '' ?>>Par Date</option>
                        <option value="status" <?= $sortBy == 'status' ? 'selected' : '' ?>>Par Statut</option>
                        <option value="id_topic" <?= $sortBy == 'id_topic' ? 'selected' : '' ?>>Par ID</option>
                    </select>
                    <button type="submit" class="sort-button">Trier</button>
                    <input type="hidden" name="selected_topic" id="selected_topic_input" value="<?= htmlspecialchars($selectedTopic ?? '') ?>">
                    <input type="hidden" name="user_search" value="<?= htmlspecialchars($userSearch) ?>">
                    <input type="hidden" name="user_sort_by" value="<?= htmlspecialchars($userSortBy) ?>">
                </form>
                <table class="forum-table">
                    <thead>
                        <tr>
                            <th>ID Topic</th>
                            <th>Nom Client</th>
                            <th>Message</th>
                            <th>Créé le</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($topicsWithComments as $topic): ?>
                            <tr class="topic-row <?= $topic['is_pinned'] ? 'pinned' : '' ?> <?= $selectedTopic == $topic['id_topic'] ? 'selected' : '' ?>" data-topic-id="<?= htmlspecialchars($topic['id_topic']) ?>">
                                <td><?= htmlspecialchars($topic['id_topic']) ?></td>
                                <td><?= htmlspecialchars($topic['client_name'] ?? $topic['id_client']) ?></td>
                                <td><?= htmlspecialchars($topic['topic_text']) ?></td>
                                <td><?= htmlspecialchars($topic['created_at']) ?></td>
                                <td>
                                    <?= htmlspecialchars($topic['status']) ?>
                                    <?php if ($topic['is_pinned']): ?>
                                        <span style="color: #28a745; margin-left: 5px;">(Épinglé 📍)</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($topic['status'] === 'En Attente'): ?>
                                        <form action="dashboard.php" method="POST" style="display:inline;">
                                            <input type="hidden" name="id_topic" value="<?= $topic['id_topic'] ?>">
                                            <input type="hidden" name="forum_action" value="confirm">
                                            <button type="submit" name="confirm_topic" class="action-btn confirm">Confirmer</button>
                                        </form>
                                    <?php endif; ?>
                                    <form action="dashboard.php" method="POST" style="display:inline;">
                                        <input type="hidden" name="id_topic" value="<?= $topic['id_topic'] ?>">
                                        <input type="hidden" name="forum_action" value="delete">
                                        <button type="submit" name="delete_topic" class="action-btn delete">Supprimer</button>
                                    </form>
                                    <form action="dashboard.php" method="POST" style="display:inline;">
                                        <input type="hidden" name="id_topic" value="<?= $topic['id_topic'] ?>">
                                        <input type="hidden" name="forum_action" value="toggle_pin">
                                        <button type="submit" name="toggle_pin" class="pin-button" title="<?= $topic['is_pinned'] ? 'Désépingler' : 'Épingler' ?>">
                                            <?= $topic['is_pinned'] ? '📍' : '📌' ?>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php if (!empty($topic['comments'])): ?>
                                <?php foreach ($topic['comments'] as $comment): ?>
                                    <tr class="comment-row">
                                        <td class="comment-icon"><?= htmlspecialchars($comment['id_comment']) ?> (Commentaire)</td>
                                        <td><?= htmlspecialchars($comment['client_name']) ?></td>
                                        <td><?= htmlspecialchars($comment['comment_text']) ?></td>
                                        <td><?= htmlspecialchars($comment['created_at']) ?></td>
                                        <td><?= htmlspecialchars($comment['status']) ?> (Sentiment: <?= htmlspecialchars($comment['sentiment']) ?>)</td>
                                        <td>
                                            <form action="dashboard.php" method="POST" style="display:inline;">
                                                <input type="hidden" name="id_comment" value="<?= $comment['id_comment'] ?>">
                                                <input type="hidden" name="forum_action" value="delete_comment">
                                                <button type="submit" name="delete_comment" class="action-btn delete">Supprimer</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr class="no-comment-row">
                                    <td colspan="6">Aucun commentaire pour ce topic.</td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>



        <!-- Statistiques -->
        <section class="stats-section">
            <h2>Statistiques des Clients</h2>
            <div class="chart-legend">
                <div class="legend-item">
                    <span class="legend-color legend-topics"></span>
                    <span>Topics</span>
                </div>
                <div class="legend-item">
                    <span class="legend-color legend-comments"></span>
                    <span>Commentaires</span>
                </div>
            </div>
            <div class="stats-chart-wrapper">
                <div class="chart-y-axis">
                    <?php for ($i = ceil($maxCount); $i >= 0; $i--): ?>
                        <div class="y-tick"><?= $i ?></div>
                    <?php endfor; ?>
                </div>
                <div class="stats-chart">
                    <?php foreach ($clientStats as $stat): ?>
                        <div class="chart-bar-group">
                            <div class="bars-container">
                                <div class="chart-bar chart-bar-topics" style="height: <?= ($stat['topic_count'] / $maxCount) * 150 ?>px;" title="Topics: <?= htmlspecialchars($stat['topic_count']) ?>">
                                    <span class="bar-value"><?= htmlspecialchars($stat['topic_count']) ?></span>
                                </div>
                                <div class="chart-bar chart-bar-comments" style="height: <?= ($stat['comment_count'] / $maxCount) * 150 ?>px;" title="Commentaires: <?= htmlspecialchars($stat['comment_count']) ?>">
                                    <span class="bar-value"><?= htmlspecialchars($stat['comment_count']) ?></span>
                                </div>
                            </div>
                            <div class="chart-label"><?= htmlspecialchars($stat['client_name'] ?? $stat['id_client']) ?></div>
                        </div>
                    <?php endforeach; ?>
                    <?php if (empty($clientStats)): ?>
                        <p class="no-data">Aucune activité pour le moment.</p>
                    <?php endif; ?>
                </div>
            </div>
        </section>

        <!-- Sentiment des Commentaires -->
        <section class="sentiment-section">
            <h2>Sentiment des Commentaires <?= $selectedTopic ? 'du Topic ' . htmlspecialchars($selectedTopic) : '(Sélectionnez un topic)' ?></h2>
            <?php
            $total = $sentimentCounts['positif'] + $sentimentCounts['négatif'] + $sentimentCounts['neutre'];
            $positivePercent = $total > 0 ? ($sentimentCounts['positif'] / $total) * 100 : 0;
            $negativePercent = $total > 0 ? ($sentimentCounts['négatif'] / $total) * 100 : 0;
            $neutralPercent = $total > 0 ? ($sentimentCounts['neutre'] / $total) * 100 : 0;
            ?>
            <div class="bar-chart">
                <div class="bar-chart-container">
                    <div class="bar-segment negative-segment" style="width: <?= $negativePercent ?>%;"><?= $negativePercent > 0 ? '😞' : '' ?></div>
                    <div class="bar-segment neutral-segment" style="width: <?= $neutralPercent ?>%;"><?= $neutralPercent > 0 ? '😐' : '' ?></div>
                    <div class="bar-segment positive-segment" style="width: <?= $positivePercent ?>%;"><?= $positivePercent > 0 ? '😊' : '' ?></div>
                </div>
            </div>
            <div class="sentiment-legend">
                <div class="legend-item">
                    <span class="legend-color sentiment-positive"></span>
                    <span>Positif (<?= $sentimentCounts['positif'] ?> - <?= number_format($positivePercent, 1) ?>%)</span>
                </div>
                <div class="legend-item">
                    <span class="legend-color sentiment-negative"></span>
                    <span>Négatif (<?= $sentimentCounts['négatif'] ?> - <?= number_format($negativePercent, 1) ?>%)</span>
                </div>
                <div class="legend-item">
                    <span class="legend-color sentiment-neutral"></span>
                    <span>Neutre (<?= $sentimentCounts['neutre'] ?> - <?= number_format($neutralPercent, 1) ?>%)</span>
                </div>
            </div>
        </section>






<!-- -------------------------------------------------------------------------------------------------------------------------------------- -->







        <!-- Événements -->
                <div class="dashboard-panels">
            <div class="panel forum-admin">
                <h3>Gestion des Événements</h3>
                <div style="padding: 20px; display: flex; justify-content: space-between;">
                    <button class="action-btn primary" onclick="openModal()">➕ Ajouter un événement</button>
                    <a href="../../Front-End/front.php" class="action-btn" style="background-color: #3498db; color: white;">🌐 Voir le site public</a>
                </div>
                <form method="GET" action="dashboard.php" class="search-form">
                    <input type="text" name="search" class="search-input" placeholder="Rechercher par nom d'événement" value="<?= htmlspecialchars($searchTerm) ?>" />
                    <select name="sort" class="sort-select">
                        <option value="date_asc" <?= $sortOption == 'date_asc' ? 'selected' : '' ?>>Date (plus anciens)</option>
                        <option value="date_desc" <?= $sortOption == 'date_desc' ? 'selected' : '' ?>>Date (plus récents)</option>
                        <option value="title_asc" <?= $sortOption == 'title_asc' ? 'selected' : '' ?>>Titre (A-Z)</option>
                        <option value="title_desc" <?= $sortOption == 'title_desc' ? 'selected' : '' ?>>Titre (Z-A)</option>
                    </select>
                    <button type="submit" class="sort-button">Appliquer</button>
                    <?php if ($searchTerm || $sortOption != 'date_desc'): ?>
                        <a href="dashboard.php" class="action-btn">Réinitialiser</a>
                    <?php endif; ?>
                </form>
                <p class="search-results-count">
                    <?= $totalEvents ?> événement(s) trouvé(s) <?= $searchTerm ? 'pour la recherche "' . htmlspecialchars($searchTerm) . '"' : '' ?>
                </p>
                <table class="forum-table">
                    <thead>
                        <tr>
                            <th>Titre</th>
                            <th>Description</th>
                            <th>Type</th>
                            <th>Date</th>
                            <th>Image</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($evenements as $event): ?>
                            <tr>
                                <td><?= htmlspecialchars($event->getTitre()) ?></td>
                                <td><?= htmlspecialchars(substr($event->getDescription(), 0, 100)) ?>...</td>
                                <td><?= htmlspecialchars($event->getType()) ?></td>
                                <td><?= $event->getDateE() ? htmlspecialchars(date('d/m/Y', strtotime($event->getDateE()))) : '-' ?></td>
                                <td>
                                    <?php 
                                    $imagePath = $event->getImage();
                                    if ($imagePath) {
                                        $imagePath = str_replace('../../../', '/', $imagePath);
                                    }
                                    ?>
                                    <?php if ($imagePath): ?>
                                        <img src="<?= htmlspecialchars($imagePath) ?>" alt="Event" class="event-image" style="max-width: 80px; height: auto;" onerror="this.src='../../Ressources/no-image.png';">
                                    <?php else: ?>
                                        <div class="event-image" style="width:60px;height:60px;background:#e0e0e0;display:flex;align-items:center;justify-content:center;font-size:10px;color:#666;border-radius:6px;">No Image</div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <button class="action-btn edit" onclick="editEvent(<?= $event->getId() ?>, '<?= htmlspecialchars(addslashes($event->getTitre())) ?>', '<?= htmlspecialchars(addslashes($event->getDescription())) ?>', '<?= htmlspecialchars(addslashes($event->getType())) ?>', '<?= $event->getDateE() ? htmlspecialchars($event->getDateE()) : '' ?>')">✏️ Modifier</button>
                                    <button class="action-btn primary" onclick="viewReservations(<?= $event->getId() ?>, '<?= htmlspecialchars(addslashes($event->getTitre())) ?>')">🎟️ Réservations</button>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?= $event->getId() ?>">
                                        <button type="submit" class="action-btn delete" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cet événement ?')">🗑️ Supprimer</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <div class="pagination">
                    <?php if ($currentPage > 1): ?>
                        <a href="?page=<?= $currentPage - 1 ?>&search=<?= urlencode($searchTerm) ?>&sort=<?= $sortOption ?>" class="pagination-btn">Précédent</a>
                    <?php else: ?>
                        <button class="pagination-btn" disabled>Précédent</button>
                    <?php endif; ?>
                    <?php
                    $startPage = max(1, $currentPage - 2);
                    $endPage = min($totalPages, $startPage + 4);
                    if ($endPage == $totalPages) {
                        $startPage = max(1, $endPage - 4);
                    }
                    for ($i = $startPage; $i <= $endPage; $i++):
                    ?>
                        <a href="?page=<?= $i ?>&search=<?= urlencode($searchTerm) ?>&sort=<?= $sortOption ?>" class="pagination-btn <?= $i == $currentPage ? 'active' : '' ?>"><?= $i ?></a>
                    <?php endfor; ?>
                    <?php if ($currentPage < $totalPages): ?>
                        <a href="?page=<?= $currentPage + 1 ?>&search=<?= urlencode($searchTerm) ?>&sort=<?= $sortOption ?>" class="pagination-btn">Suivant</a>
                    <?php else: ?>
                        <button class="pagination-btn" disabled>Suivant</button>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Modal pour ajouter/modifier un événement -->
        <div id="eventModal" class="modal">
            <div class="modal-content">
                <span class="close" onclick="closeModal()">×</span>
                <h2 id="modalTitle">Ajouter un événement</h2>
                <form method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="action" id="form-action" value="create">
                    <input type="hidden" name="id" id="event-id" value="">
                    <div class="form-group">
                        <label for="titre">Titre</label>
                        <input type="text" id="titre" name="titre" class="form-control" onchange="validateTitre(this)">
                        <span class="error-message" id="titre-error"></span>
                    </div>
                    <div class="form-group">
                        <label for="description">Description</label>
                        <textarea id="description" name="description" class="form-control" rows="3" onchange="validateDescription(this)"></textarea>
                        <span class="error-message" id="description-error"></span>
                    </div>
                    <div class="form-group">
                        <label for="type">Type</label>
                        <input type="text" id="type" name="type" class="form-control" onchange="validateType(this)">
                        <span class="error-message" id="type-error"></span>
                    </div>
                    <div class="form-group">
                        <label for="dateE">Date de l'événement</label>
                        <input type="date" id="dateE" name="dateE" class="form-control" onchange="validateDate(this)">
                        <span class="error-message" id="dateE-error"></span>
                    </div>
                    <div class="form-group">
                        <label for="image">Image</label>
                        <input type="file" id="image" name="image" class="form-control" accept="image/*">
                    </div>
                    <button type="submit" class="action-btn primary">Enregistrer</button>
                </form>
            </div>
        </div>

        <!-- Modal des réservations -->
        <div id="reservationsModal" class="reservations-modal">
            <div class="reservations-modal-content">
                <span class="close" onclick="closeReservationsModal()">×</span>
                <h2 id="reservationsModalTitle">Réservations de l'événement</h2>
                <div id="reservationsList"></div>
            </div>
        </div>
    </div>

    <footer>
        <p>© 2025 Green City - Horizon Digital | All Rights Reserved</p>
    </footer>

    <script>
        // Validation du formulaire
        function validateTitre(input) {
            const error = document.getElementById('titre-error');
            if (!input.value.trim()) {
                error.textContent = 'Veuillez entrer un titre';
                input.classList.add('error');
                return false;
            }
            error.textContent = '';
            input.classList.remove('error');
            return true;
        }

        function validateDescription(input) {
            const error = document.getElementById('description-error');
            if (!input.value.trim()) {
                error.textContent = 'Veuillez entrer une description';
                input.classList.add('error');
                return false;
            }
            error.textContent = '';
            input.classList.remove('error');
            return true;
        }

        function validateType(input) {
            const error = document.getElementById('type-error');
            if (!input.value.trim()) {
                error.textContent = 'Veuillez entrer un type';
                input.classList.add('error');
                return false;
            }
            error.textContent = '';
            input.classList.remove('error');
            return true;
        }

        function validateDate(input) {
            const error = document.getElementById('dateE-error');
            if (!input.value.trim()) {
                error.textContent = 'Veuillez sélectionner une date';
                input.classList.add('error');
                return false;
            }
            error.textContent = '';
            input.classList.remove('error');
            return true;
        }

        function validateForm() {
            return validateTitre(document.getElementById('titre')) &&
                   validateDescription(document.getElementById('description')) &&
                   validateType(document.getElementById('type')) &&
                   validateDate(document.getElementById('dateE'));
        }

        // Gestion du modal
        function openModal() {
            document.querySelector('#eventModal form').reset();
            document.querySelectorAll('.error-message').forEach(el => el.textContent = '');
            document.querySelectorAll('.form-control').forEach(input => input.classList.remove('error'));
            document.getElementById('eventModal').style.display = 'block';
            document.getElementById('modalTitle').textContent = 'Ajouter un événement';
            document.getElementById('form-action').value = 'create';
            document.getElementById('event-id').value = '';
        }

        function closeModal() {
            document.getElementById('eventModal').style.display = 'none';
        }

        function editEvent(id, titre, description, type, dateE) {
            document.querySelector('#eventModal form').reset();
            document.querySelectorAll('.error-message').forEach(el => el.textContent = '');
            document.querySelectorAll('.form-control').forEach(input => input.classList.remove('error'));
            document.getElementById('eventModal').style.display = 'block';
            document.getElementById('modalTitle').textContent = 'Modifier l\'événement';
            document.getElementById('form-action').value = 'update';
            document.getElementById('event-id').value = id;
            document.getElementById('titre').value = decodeHTML(titre);
            document.getElementById('description').value = decodeHTML(description);
            document.getElementById('type').value = decodeHTML(type);
            document.getElementById('dateE').value = decodeHTML(dateE);
        }

        function decodeHTML(html) {
            const textarea = document.createElement('textarea');
            textarea.innerHTML = html;
            return textarea.value;
        }

        // Gestion des réservations
        async function viewReservations(eventId, eventTitle) {
            const modal = document.getElementById('reservationsModal');
            const modalTitle = document.getElementById('reservationsModalTitle');
            const reservationsList = document.getElementById('reservationsList');
            modalTitle.textContent = `Réservations pour : ${eventTitle}`;
            reservationsList.innerHTML = '<p>Chargement des réservations...</p>';
            modal.style.display = 'block';
            try {
                const response = await fetch(`../../controller/ReservationC.php?evenement_id=${eventId}`);
                const data = await response.json();
                if (data.status === 'success' && data.data.length > 0) {
                    reservationsList.innerHTML = data.data.map(reservation => `
                        <div class="reservation-card">
                            <div class="reservation-header">
                                <h3>${reservation.fullname}</h3>
                                <span class="reservation-status status-${reservation.statut}">${formatStatus(reservation.statut)}</span>
                            </div>
                            <div class="reservation-info">
                                <div class="reservation-info-item">
                                    <span class="info-label">Email</span>
                                    <span class="info-value">${reservation.email}</span>
                                </div>
                                <div class="reservation-info-item">
                                    <span class="info-label">Date</span>
                                    <span class="info-value">${formatDate(reservation.date)}</span>
                                </div>
                                <div class="reservation-info-item">
                                    <span class="info-label">Participants</span>
                                    <span class="info-value">${reservation.participants}</span>
                                </div>
                                ${reservation.allergies ? `
                                    <div class="reservation-info-item">
                                        <span class="info-label">Allergies</span>
                                        <span class="info-value">${reservation.allergies}</span>
                                    </div>
                                ` : ''}
                            </div>
                            <div class="status-actions">
                                ${reservation.statut === 'en_attente' ? `
                                    <button class="status-btn confirm-btn" onclick="updateReservationStatus(${reservation.id}, 'confirmé')">Confirmer</button>
                                    <button class="status-btn cancel-btn" onclick="updateReservationStatus(${reservation.id}, 'annulé')">Annuler</button>
                                ` : ''}
                            </div>
                        </div>
                    `).join('');
                } else {
                    reservationsList.innerHTML = '<p>Aucune réservation trouvée pour cet événement.</p>';
                }
            } catch (error) {
                reservationsList.innerHTML = '<p>Erreur lors du chargement des réservations.</p>';
            }
        }

        function closeReservationsModal() {
            document.getElementById('reservationsModal').style.display = 'none';
        }

        function formatStatus(status) {
            const statusMap = {
                'en_attente': '⏳ En attente',
                'confirmé': '✅ Confirmé',
                'annulé': '❌ Annulé'
            };
            return statusMap[status] || status;
        }

        function formatDate(dateStr) {
            return new Date(dateStr).toLocaleDateString('fr-FR', { year: 'numeric', month: 'long', day: 'numeric' });
        }

        async function updateReservationStatus(reservationId, newStatus) {
            const parentCard = event.target.closest('.reservation-card');
            parentCard.innerHTML = `<div style="text-align: center; padding: 20px;"><p>${newStatus === 'confirmé' ? 'Confirmation' : 'Annulation'} en cours...</p></div>`;
            try {
                const statusResponse = await fetch('../../controller/ReservationC.php', {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id: reservationId, statut: newStatus })
                });
                const statusResult = await statusResponse.json();
                if (statusResult.status === 'success') {
                    const deleteResponse = await fetch(`../../controller/ReservationC.php?id=${reservationId}`, { method: 'DELETE' });
                    const deleteResult = await deleteResponse.json();
                    if (deleteResult.status === 'success') {
                        parentCard.remove();
                        const notification = document.createElement('div');
                        notification.style.cssText = `
                            position: fixed; bottom: 20px; right: 20px; background: #e8f5e9; padding: 15px 20px;
                            border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); z-index: 1100; opacity: 0;
                            transition: opacity 0.3s ease;
                        `;
                        const message = statusResult.email_sent ? `Réservation ${newStatus === 'confirmé' ? 'confirmée' : 'annulée'} et supprimée. Email envoyé !` : `Réservation ${newStatus === 'confirmé' ? 'confirmée' : 'annulée'} et supprimée !`;
                        notification.innerHTML = `<p style="color: #2e7d32; font-weight: bold; margin: 0;">✅ ${message}</p>`;
                        document.body.appendChild(notification);
                        setTimeout(() => { notification.style.opacity = '1'; }, 10);
                        setTimeout(() => {
                            notification.style.opacity = '0';
                            setTimeout(() => notification.remove(), 300);
                        }, 3000);
                    } else {
                        throw new Error(deleteResult.message || 'Erreur lors de la suppression');
                    }
                } else {
                    throw new Error(statusResult.message || 'Erreur lors de la mise à jour');
                }
            } catch (error) {
                parentCard.innerHTML = `
                    <div style="text-align: center; padding: 20px; background: #ffebee; border-radius: 8px; margin: 10px 0;">
                        <p style="color: #c62828; font-weight: bold;">❌ Erreur: ${error.message}</p>
                        <button onclick="location.reload()" style="padding: 8px 16px; background: #f5f5f5; border: none; border-radius: 4px; cursor: pointer; margin-top: 10px;">Réessayer</button>
                    </div>`;
            }
        }

        // Gestion de la sélection des topics
        document.addEventListener('DOMContentLoaded', () => {
            document.querySelectorAll('.topic-row').forEach(row => {
                row.addEventListener('click', () => {
                    const topicId = row.getAttribute('data-topic-id');
                    const url = new URL(window.location.href);
                    url.searchParams.set('selected_topic', topicId);
                    window.location.href = url.toString();
                });
            });
            document.querySelector('#eventModal form').addEventListener('submit', e => {
                if (!validateForm()) {
                    e.preventDefault();
                    alert('Veuillez corriger les erreurs dans le formulaire.');
                }
            });
        });

        window.onclick = function(event) {
            if (event.target === document.getElementById('eventModal')) closeModal();
            if (event.target === document.getElementById('reservationsModal')) closeReservationsModal();
        };
    </script>
</body>
</html>