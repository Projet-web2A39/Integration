<?php
require_once __DIR__ . '/../../Controller/EvenementC.php';

//events
$controller = new EvenementController();

// For debugging form submissions
$debug_form = isset($_GET['debug_form']);

// Pagination settings
$itemsPerPage = 5; // Number of events per page
$currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if($currentPage < 1) $currentPage = 1;

// Search and sort parameters
$searchTerm = isset($_GET['search']) ? trim($_GET['search']) : '';
$sortOption = isset($_GET['sort']) ? $_GET['sort'] : 'date_desc';

// Get all events and apply filtering/sorting
$allEvenements = $controller->getAllEvenements();

// Filter by search term if specified
if (!empty($searchTerm)) {
    $allEvenements = array_filter($allEvenements, function($event) use ($searchTerm) {
        return stripos($event->getTitre(), $searchTerm) !== false;
    });
}

// Sort events according to selected option
switch ($sortOption) {
    case 'date_asc':
        usort($allEvenements, function($a, $b) {
            $dateA = $a->getDateE() ? strtotime($a->getDateE()) : 0;
            $dateB = $b->getDateE() ? strtotime($b->getDateE()) : 0;
            return $dateA - $dateB;
        });
        break;
    case 'date_desc':
        usort($allEvenements, function($a, $b) {
            $dateA = $a->getDateE() ? strtotime($a->getDateE()) : 0;
            $dateB = $b->getDateE() ? strtotime($b->getDateE()) : 0;
            return $dateB - $dateA;
        });
        break;
    case 'title_asc':
        usort($allEvenements, function($a, $b) {
            return strcmp($a->getTitre(), $b->getTitre());
        });
        break;
    case 'title_desc':
        usort($allEvenements, function($a, $b) {
            return strcmp($b->getTitre(), $a->getTitre());
        });
        break;
}

// Reindex array after filtering
$allEvenements = array_values($allEvenements);

// Calculate pagination
$totalEvents = count($allEvenements);
$totalPages = ceil($totalEvents / $itemsPerPage);

// Calculate offsets
$offset = ($currentPage - 1) * $itemsPerPage;

// Get limited events for current page
$evenements = array_slice($allEvenements, $offset, $itemsPerPage);

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($debug_form) {
        echo "<div style='background:#f8f8f8; border:1px solid #ddd; padding:15px; margin:15px;'>";
        echo "<h3>Form Debug</h3>";
        echo "<pre>";
        print_r($_POST);
        echo "</pre>";
        echo "<h4>Files</h4>";
        echo "<pre>";
        print_r($_FILES);
        echo "</pre>";
        echo "</div>";
    }

    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'create':
            case 'update':
                $titre = $_POST['titre'];
                $description = $_POST['description'];
                $type = $_POST['type'];
                $dateE = $_POST['dateE'];
                
                // Handle image upload
                $image = '';
                if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
                    // Make sure uploads directory exists with correct permissions
                    $uploadDir = '../../../uploads/events/';
                    $absoluteUploadDir = $_SERVER['DOCUMENT_ROOT'] . '/Haifa/phphaifa/uploads/events/';
                    
                    if (!is_dir($absoluteUploadDir)) {
                        mkdir($absoluteUploadDir, 0777, true);
                    }
                    
                    // Generate unique filename
                    $filename = uniqid() . '-' . basename($_FILES['image']['name']);
                    $targetPath = $uploadDir . $filename;
                    $absoluteTargetPath = $absoluteUploadDir . $filename;
                    
                    // Move the uploaded file
                    if (move_uploaded_file($_FILES['image']['tmp_name'], $absoluteTargetPath)) {
                        // Store the web-accessible path (not the absolute filesystem path)
                        $image = $uploadDir . $filename;
                    }
                }
                
                if ($_POST['action'] === 'create') {
                    $controller->createEvenement($titre, $description, $image, $type, $dateE);
                } else {
                    $id = (int)$_POST['id'];
                    
                    if ($debug_form) {
                        echo "<div style='background:#f8f8f8; border:1px solid #ddd; padding:15px; margin:15px;'>";
                        echo "<h3>Update Operation</h3>";
                        echo "ID: $id<br>";
                        echo "Titre: $titre<br>";
                        echo "Type: $type<br>";
                        echo "Date: $dateE<br>";
                        echo "Image: " . ($image ? $image : "No new image") . "<br>";
                        echo "</div>";
                    }
                    
                    $currentEvent = $controller->getEvenementById($id);
                    
                    if (!$currentEvent) {
                        // Handle error - event not found
                        echo "<script>alert('Erreur: Événement non trouvé.');</script>";
                    } else {
                        // Only update the image if a new one was uploaded
                        $imageToUpdate = !empty($image) ? $image : $currentEvent->getImage();
                        $success = $controller->updateEvenement($id, $titre, $description, $imageToUpdate, $type, $dateE);
                        
                        if (!$success) {
                            echo "<script>alert('Erreur lors de la mise à jour de l\'événement.');</script>";
                        }
                    }
                }
                
                if (!$debug_form) {
                    header('Location: ' . $_SERVER['PHP_SELF'] . '?page=' . $currentPage);
                    exit;
                }
                break;
                
            case 'delete':
                if (isset($_POST['id'])) {
                    $controller->deleteEvenement($_POST['id']);
                    if (!$debug_form) {
                        header('Location: ' . $_SERVER['PHP_SELF'] . '?page=' . $currentPage);
                        exit;
                    }
                }
                break;
        }
    }
}

// Build pagination parameters
$paginationParams = [];
if (!empty($searchTerm)) {
    $paginationParams['search'] = $searchTerm;
}
if (!empty($sortOption) && $sortOption != 'date_desc') {
    $paginationParams['sort'] = $sortOption;
}

?>