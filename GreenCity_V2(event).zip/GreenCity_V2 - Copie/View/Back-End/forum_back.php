<?php
require_once '../../model/ForumTopic.php';
require_once '../../model/ForumComment.php';

// Initialisation Topic et Comment
$forumTopic = new ForumTopic();
$forumComment = new ForumComment();

// Récupérer la recherche et le tri pour les topics
$search = isset($_GET['search']) ? $_GET['search'] : '';
$sortBy = isset($_GET['sort_by']) ? $_GET['sort_by'] : 'created_at';
$selectedTopic = isset($_GET['selected_topic']) ? (int)$_GET['selected_topic'] : null;

// Statistiques : Nombre de topics et commentaires par client
$statsQuery = "
    SELECT 
        t.id_client,
        CONCAT(u.Nom, ' ', u.Prenom) AS client_name,
        COUNT(DISTINCT t.id_topic) AS topic_count,
        COUNT(c.id_comment) AS comment_count
    FROM topics t
    LEFT JOIN comments c ON t.id_topic = c.id_topic
    LEFT JOIN user u ON CAST(t.id_client AS UNSIGNED) = u.Id
    GROUP BY t.id_client
    HAVING topic_count > 0
    ORDER BY topic_count DESC, comment_count DESC
";
$statsStmt = $pdo->prepare($statsQuery);
$statsStmt->execute();
$clientStats = $statsStmt->fetchAll(PDO::FETCH_ASSOC);

// Calculer la somme maximale des topics et commentaires par client
$maxSomme = 0;
foreach ($clientStats as $stat) {
    $somme = $stat['topic_count'] + $stat['comment_count'];
    $maxSomme = max($maxSomme, $somme);
}
$maxCount = $maxSomme + 1; // Ajouter 1 à la somme maximale pour l'axe Y
$maxCount = $maxCount ?: 1; // Éviter la division par zéro

// Gérer les actions de confirmation, suppression et épinglage pour topics et commentaires
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['confirm_topic'])) {
        $id_topic = (int)$_POST['id_topic'];
        $forumTopic->confirmTopic($id_topic);
    } elseif (isset($_POST['delete_topic'])) {
        $id_topic = (int)$_POST['id_topic'];
        $forumTopic->deleteTopic($id_topic);
    } elseif (isset($_POST['delete_comment'])) {
        $id_comment = (int)$_POST['id_comment'];
        $forumComment->deleteComment($id_comment);
    } elseif (isset($_POST['toggle_pin'])) {
        $id_topic = (int)$_POST['id_topic'];
        $forumTopic->togglePin($id_topic);
    }
    // Rafraîchir la page après action
    header("Location: dashboard.php?search=" . urlencode($search) . "&sort_by=" . urlencode($sortBy) . (isset($_GET['selected_topic']) ? "&selected_topic=" . urlencode($_GET['selected_topic']) : "") . "&user_search=" . urlencode($userSearch) . "&user_sort_by=" . urlencode($userSortBy));
    exit;
}

// Récupérer les topics avec leurs commentaires associés via une jointure
$query = "
    SELECT 
        t.id_topic, t.id_client AS topic_client, CONCAT(u.Nom, ' ', u.Prenom) AS client_name, 
        t.topic_text, t.created_at AS topic_created_at, t.status AS topic_status, t.is_pinned,
        c.id_comment, c.client_name AS comment_client_name, c.comment_text, 
        c.created_at AS comment_created_at, c.status AS comment_status, c.sentiment
    FROM topics t
    LEFT JOIN user u ON CAST(t.id_client AS UNSIGNED) = u.Id
    LEFT JOIN comments c ON t.id_topic = c.id_topic
";

if ($search) {
    $query .= " WHERE (u.Nom LIKE :search OR u.Prenom LIKE :search OR t.id_client LIKE :search)";
}

if ($sortBy === 'status') {
    $query .= " ORDER BY t.is_pinned DESC, CASE t.status WHEN 'En Attente' THEN 0 ELSE 1 END, t.status ASC, c.created_at DESC";
} else {
    $query .= " ORDER BY t.is_pinned DESC, t.$sortBy DESC, c.created_at DESC";
}
$stmt = $pdo->prepare($query);

if ($search) {
    $stmt->bindValue(':search', '%' . $search . '%');
}

$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fonction simple pour analyser le sentiment (à remplacer par une API en production)
function analyzeSentiment($text) {
    $text = strtolower(trim($text));
    $positiveWords = ['bon', 'super', 'bien', 'good', 'salutt', 'hello', 'yes', 'up', 'nice'];
    $negativeWords = ['mauvais', 'nul', 'pire', 'mal'];
    
    if (strpos($text, 'delete') !== false) return 'négatif';
    foreach ($positiveWords as $word) {
        if (strpos($text, $word) !== false) return 'positif';
    }
    foreach ($negativeWords as $word) {
        if (strpos($text, $word) !== false) return 'négatif';
    }
    return 'neutre';
}

// Regrouper les données pour faciliter l'affichage (topics avec leurs commentaires)
$topicsWithComments = [];
$sentimentCounts = ['positif' => 0, 'négatif' => 0, 'neutre' => 0];
foreach ($results as $row) {
    $topicId = $row['id_topic'];
    if (!isset($topicsWithComments[$topicId])) {
        $topicsWithComments[$topicId] = [
            'id_topic' => $row['id_topic'],
            'id_client' => $row['topic_client'],
            'client_name' => $row['client_name'],
            'topic_text' => $row['topic_text'],
            'created_at' => $row['topic_created_at'],
            'status' => $row['topic_status'],
            'is_pinned' => isset($row['is_pinned']) ? $row['is_pinned'] : false,
            'comments' => []
        ];
    }
    if ($row['id_comment']) {
        $sentiment = $row['sentiment'] ?? analyzeSentiment($row['comment_text']);
        $topicsWithComments[$topicId]['comments'][] = [
            'id_comment' => $row['id_comment'],
            'client_name' => $row['comment_client_name'],
            'comment_text' => $row['comment_text'],
            'created_at' => $row['comment_created_at'],
            'status' => $row['comment_status'],
            'sentiment' => $sentiment
        ];
        if ($selectedTopic === null || $selectedTopic == $topicId) {
            $sentimentCounts[$sentiment]++;
        }
    }
}
?>