<?php
require "../../Controller/userController.php";

// Connexion à la base de données
$database = new Database();
$pdo = $database->getConnection();

// Récupérer la recherche et le tri pour les utilisateurs
$userSearch = isset($_GET['user_search']) ? $_GET['user_search'] : '';
$userSortBy = isset($_GET['user_sort_by']) ? $_GET['user_sort_by'] : 'Id';

// Récupérer tous les utilisateurs avec recherche et tri
$userQuery = "SELECT * FROM user";
if ($userSearch) {
    $userQuery .= " WHERE Id LIKE :user_search OR Nom LIKE :user_search OR Prenom LIKE :user_search";
}
$userQuery .= " ORDER BY $userSortBy ASC";
$userStmt = $pdo->prepare($userQuery);
if ($userSearch) {
    $userStmt->bindValue(':user_search', '%' . $userSearch . '%');
}
$userStmt->execute();
$allUsers = $userStmt->fetchAll(PDO::FETCH_ASSOC);

?>
