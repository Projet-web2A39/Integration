<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Green City - Calendrier des Événements</title>
    <link rel="stylesheet" href="interface.css">
    <link rel="stylesheet" href="style.css">
    <link rel="icon" href="../../../phphaifa/icon.png" type="image/png">
    
    <!-- FullCalendar CSS -->
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@5.10.1/main.min.css" rel="stylesheet">
    
    <style>
        .calendar-section {
            max-width: 1200px;
            margin: 50px auto;
            padding: 0 20px;
        }

        .section-title {
            text-align: center;
            color: #2e7d32;
            font-size: 2rem;
            margin-bottom: 40px;
        }
        
        #calendar {
            background-color: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        
        .fc-event {
            cursor: pointer;
            border-radius: 4px;
        }
        
        .fc-event-title {
            font-weight: 500;
        }
        
        .fc-theme-standard .fc-scrollgrid {
            border: 1px solid #eee;
        }
        
        .fc .fc-button-primary {
            background-color: #2e7d32;
            border-color: #2e7d32;
        }
        
        .fc .fc-button-primary:hover {
            background-color: #1b5e20;
            border-color: #1b5e20;
        }
        
        .fc-daygrid-day:hover {
            background-color: #f5f5f5;
        }
        
        /* Event Modal */
        .event-modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
        }

        .event-modal-content {
            background-color: #fff;
            margin: 5% auto;
            padding: 30px;
            width: 90%;
            max-width: 600px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
            position: relative;
        }

        .close-modal {
            position: absolute;
            right: 20px;
            top: 15px;
            font-size: 24px;
            cursor: pointer;
            color: #666;
            transition: color 0.3s ease;
        }

        .close-modal:hover {
            color: #000;
        }
        
        .event-image {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .event-title {
            font-size: 1.8rem;
            color: #2e7d32;
            margin-bottom: 10px;
        }
        
        .event-details {
            margin-bottom: 20px;
        }
        
        .event-detail {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 10px;
            color: #555;
        }
        
        .event-detail-icon {
            font-size: 1.2rem;
            color: #2e7d32;
        }
        
        .event-description {
            line-height: 1.6;
            color: #333;
            margin-bottom: 25px;
        }
        
        .event-actions {
            display: flex;
            gap: 10px;
        }
        
        .action-button {
            padding: 8px 16px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 500;
            text-decoration: none;
            transition: background-color 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }

        .primary-button {
            background-color: #2e7d32;
            color: white;
        }

        .primary-button:hover {
            background-color: #1b5e20;
        }

        .secondary-button {
            background-color: #f5f5f5;
            color: #2e7d32;
        }

        .secondary-button:hover {
            background-color: #e0e0e0;
        }
        
        /* Year/Month toggle buttons */
        .view-toggle {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
            gap: 10px;
        }
        
        .toggle-btn {
            padding: 8px 16px;
            background: #f5f5f5;
            border: 1px solid #ddd;
            border-radius: 4px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .toggle-btn.active {
            background: #2e7d32;
            color: white;
            border-color: #2e7d32;
        }
        
        /* Hero Section */
        .hero {
            background-image: url('../Ressources/hero-bg.jpg');
            background-size: cover;
            background-position: center;
            height: 300px;
            position: relative;
            margin-bottom: 50px;
        }

        .hero-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            padding: 20px;
        }

        .hero-content {
            color: white;
            max-width: 800px;
        }

        .hero-content h1 {
            font-size: 2.5rem;
            margin-bottom: 20px;
        }

        .hero-content p {
            font-size: 1.2rem;
            margin-bottom: 30px;
        }
        
        /* Reservation form styles */
        .reservation-form {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        
        .modal-header {
            border-bottom: 2px solid #e8f5e9;
            padding-bottom: 15px;
            margin-bottom: 20px;
            position: relative;
        }
        
        .modal-header h2 {
            color: #2e7d32;
            font-size: 1.8rem;
            margin: 0;
        }
        
        .modal-header::after {
            content: "";
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 60px;
            height: 4px;
            background-color: #2e7d32;
            border-radius: 2px;
        }
        
        .form-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        
        .form-group label {
            font-weight: 500;
            color: #2c3e50;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .form-group label .label-icon {
            color: #2e7d32;
            font-size: 1.2rem;
        }
        
        .form-group input,
        .form-group textarea {
            padding: 14px;
            border: 1px solid #dce4ec;
            border-radius: 8px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background-color: #f9f9f9;
        }
        
        .form-group input:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #2e7d32;
            box-shadow: 0 0 0 3px rgba(46, 125, 50, 0.1);
            background-color: #fff;
        }
        
        .form-group input:hover,
        .form-group textarea:hover {
            border-color: #aaa;
            background-color: #f5f5f5;
        }
        
        .submit-btn {
            padding: 14px;
            border: none;
            border-radius: 8px;
            background-color: #2e7d32;
            color: white;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
            width: 100%;
            margin-top: 10px;
        }
        
        .submit-btn:hover {
            background-color: #1b5e20;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        
        .submit-btn:active {
            transform: translateY(0);
        }
        
        .submit-btn:disabled {
            background-color: #a5d6a7;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }
        
        .required-field {
            color: #e74c3c;
            margin-left: 4px;
        }
        
        .error-message {
            color: #e74c3c;
            font-size: 0.85rem;
            margin-top: 5px;
            display: block;
        }
        
        input.error, textarea.error {
            border-color: #e74c3c;
        }
    </style>
</head>
<body>
    <header>
        <img src="../Ressources/logo_GreenCity_trans.png" width="20%" alt="Green City Logo" id="logo_header">
        <nav>
            <a href="../Front-End/interface.php">Home</a>
            <a href="events.php">Events</a>
            <a href="forum.php">Forum</a>
            <a href="defi.php">Challenges</a>
            <a href="calendrier.php" class="active">Calendrier</a>
            <a href="../Back-End/View/dashboard.php">Dashboard</a>
        </nav>
        <a href="user.php" class="profile-link">
            <img src="../../<?= $userInfo['Img'] ?? 'Ressources/profile.png' ?>" alt="Profile Icon" class="profile-icon">
            <h2><?= $userInfo['Prenom'] . " " . $userInfo['Nom'] ?></h2>
        </a>
    </header>

    <section class="hero">
        <div class="hero-overlay">
            <div class="hero-content">
                <h1>Calendrier des Événements</h1>
                <p>Consultez tous nos événements écologiques dans un format de calendrier</p>
            </div>
        </div>
    </section>

    <section class="calendar-section">
        <h2 class="section-title">📅 Calendrier des Événements</h2>
        
        <div class="view-toggle">
            <button class="toggle-btn" id="monthViewBtn">Mois</button>
            <button class="toggle-btn" id="weekViewBtn">Semaine</button>
            <button class="toggle-btn" id="listViewBtn">Liste</button>
        </div>
        
        <div id="calendar"></div>
    </section>
    
    <!-- Event Modal -->
    <div id="eventModal" class="event-modal">
        <div class="event-modal-content">
            <span class="close-modal" onclick="closeEventModal()">&times;</span>
            <div id="eventDetails"></div>
        </div>
    </div>
    
    <!-- Reservation Modal -->
    <div id="reservationModal" class="event-modal">
        <div class="event-modal-content">
            <span class="close-modal" onclick="closeReservationModal()">&times;</span>
            <div class="modal-header">
                <h2>Réserver pour l'événement</h2>
            </div>
            <form id="reservationForm" class="reservation-form" onsubmit="submitReservation(event)">
                <input type="hidden" id="evenement_id" name="evenement_id">
                
                <div class="form-group">
                    <label for="fullname">
                        <span class="label-icon">👤</span>
                        Nom complet<span class="required-field">*</span>
                    </label>
                    <input id="fullname" name="fullname" placeholder="Entrez votre nom complet" onchange="validateFullname(this)">
                    <span class="error-message" id="fullname-error"></span>
                </div>

                <div class="form-group">
                    <label for="email">
                        <span class="label-icon">✉️</span>
                        Email<span class="required-field">*</span>
                    </label>
                    <input id="email" name="email" placeholder="Entrez votre adresse email" onchange="validateEmail(this)">
                    <span class="error-message" id="email-error"></span>
                </div>

                <div class="form-group">
                    <label for="date">
                        <span class="label-icon">📅</span>
                        Date<span class="required-field">*</span>
                    </label>
                    <input id="date" name="date" placeholder="AAAA-MM-JJ" onchange="validateDateFormat(this)">
                    <span class="error-message" id="date-error"></span>
                </div>

                <div class="form-group">
                    <label for="participants">
                        <span class="label-icon">👥</span>
                        Nombre de participants<span class="required-field">*</span>
                    </label>
                    <input id="participants" name="participants" placeholder="Nombre de personnes" onchange="validateParticipants(this)">
                    <span class="error-message" id="participants-error"></span>
                </div>

                <div class="form-group">
                    <label for="allergies">
                        <span class="label-icon">🩺</span>
                        Allergies ou besoins spéciaux
                    </label>
                    <textarea id="allergies" name="allergies" rows="3" placeholder="Si vous avez des allergies ou des besoins particuliers, veuillez les préciser ici"></textarea>
                </div>

                <button type="submit" class="submit-btn">
                    <span>🎟️</span> Confirmer la réservation
                </button>
            </form>
            <div id="reservationMessage"></div>
        </div>
    </div>

    <footer>
        <p>&copy; 2025 Green City - Horizon Digital | All Rights Reserved</p>
    </footer>

    <!-- FullCalendar JS -->
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.10.1/main.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.10.1/locales/fr.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Get events data from PHP
            let eventsData = [];
            
            <?php
            require_once __DIR__ . '/../../controller/EvenementC.php';
            
            $controller = new EvenementController();
            $evenements = $controller->getAllEvenements();
            
            foreach ($evenements as $event) {
                // Only add events with a date
                if ($event->getDateE()) {
                    $eventDate = $event->getDateE();
                    $eventColor = getEventColor($event->getType());
                    
                    // Normalize image path for consistency
                    $imagePath = $event->getImage();
                    if (!empty($imagePath)) {
                        // Always use a consistent path format relative to this file
                        $basename = basename($imagePath);
                        $imagePath = '../../uploads/events/' . $basename;
                        
                        // Make sure the file actually exists, or use empty string
                        $fullPath = realpath(dirname(__FILE__) . '/../../uploads/events/' . $basename);
                        if (!$fullPath || !file_exists($fullPath)) {
                            // Log missing image
                            error_log("Image file not found: $imagePath for event {$event->getId()}");
                        }
                    }
                    
                    echo "eventsData.push({
                        id: '{$event->getId()}',
                        title: '" . addslashes(htmlspecialchars($event->getTitre())) . "',
                        start: '{$eventDate}',
                        description: '" . addslashes(htmlspecialchars($event->getDescription())) . "',
                        type: '" . addslashes(htmlspecialchars($event->getType())) . "',
                        image: '" . addslashes(htmlspecialchars($imagePath)) . "',
                        color: '{$eventColor}'
                    });\n";
                }
            }
            
            // Function to assign colors based on event type
            function getEventColor($type) {
                $types = [
                    'Nettoyage' => '#4CAF50',       // Green
                    'Plantation' => '#8BC34A',       // Light Green
                    'Éducation' => '#2196F3',        // Blue
                    'Atelier' => '#FF9800',          // Orange
                    'Conférence' => '#9C27B0',       // Purple
                    'Sensibilisation' => '#E91E63',  // Pink
                    'Recyclage' => '#00BCD4'         // Cyan
                ];
                
                $lowerType = strtolower($type);
                
                foreach ($types as $key => $color) {
                    if (strpos($lowerType, strtolower($key)) !== false) {
                        return $color;
                    }
                }
                
                // Default color
                return '#3498db';
            }
            ?>
            
            // Initialize FullCalendar
            const calendarEl = document.getElementById('calendar');
            const calendar = new FullCalendar.Calendar(calendarEl, {
                initialView: 'dayGridMonth',
                locale: 'fr',
                headerToolbar: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek,listMonth'
                },
                events: eventsData,
                eventClick: function(info) {
                    showEventDetails(info.event);
                },
                eventTimeFormat: {
                    hour: '2-digit',
                    minute: '2-digit',
                    meridiem: false
                },
                firstDay: 1, // Start week on Monday
                height: 'auto',
                contentHeight: 'auto'
            });
            
            calendar.render();
            
            // Toggle buttons for different views
            document.getElementById('monthViewBtn').addEventListener('click', function() {
                calendar.changeView('dayGridMonth');
                resetActiveButtons();
                this.classList.add('active');
            });
            
            document.getElementById('weekViewBtn').addEventListener('click', function() {
                calendar.changeView('timeGridWeek');
                resetActiveButtons();
                this.classList.add('active');
            });
            
            document.getElementById('listViewBtn').addEventListener('click', function() {
                calendar.changeView('listMonth');
                resetActiveButtons();
                this.classList.add('active');
            });
            
            // Set initial active button
            document.getElementById('monthViewBtn').classList.add('active');
            
            function resetActiveButtons() {
                document.querySelectorAll('.toggle-btn').forEach(btn => {
                    btn.classList.remove('active');
                });
            }
            
            // Show event details in modal
            function showEventDetails(event) {
                const eventDetails = document.getElementById('eventDetails');
                const id = event.id;
                const title = event.title;
                const description = event.extendedProps.description;
                const type = event.extendedProps.type;
                const imagePath = event.extendedProps.image;
                const dateStr = event.start ? new Date(event.start).toLocaleDateString('fr-FR', {
                    weekday: 'long',
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                }) : 'Date non spécifiée';
                
                // Only use two possible paths - the provided path and a single fallback
                const imageBasename = imagePath ? imagePath.split('/').pop() : '';
                const fallbackPath = '../../uploads/events/' + imageBasename;
                
                // Generate HTML for event details
                let html = `
                    ${imagePath ? `
                    <img src="${imagePath}" alt="${title}" class="event-image" 
                        onerror="
                            console.log('Primary image path failed: ' + this.src);
                            this.src = '${fallbackPath}';
                            this.onerror = function() {
                                console.log('Fallback image path failed: ' + this.src);
                                this.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIyMDBweCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZTBlMGUwIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIyMCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iIGZpbGw9IiM2NjY2NjYiPkF1Y3VuZSBJbWFnZTwvdGV4dD48L3N2Zz4=';
                                this.onerror = null;
                            }
                        "
                    >` : 
                    `<div style="width:100%;height:200px;background:#e0e0e0;display:flex;align-items:center;justify-content:center;font-size:16px;color:#666;border-radius:8px;margin-bottom:20px;">Aucune Image</div>`}
                    
                    <h2 class="event-title">${title}</h2>
                    
                    <div class="event-details">
                        <div class="event-detail">
                            <span class="event-detail-icon">📅</span>
                            <span>${dateStr}</span>
                        </div>
                        <div class="event-detail">
                            <span class="event-detail-icon">📍</span>
                            <span>${type}</span>
                        </div>
                    </div>
                    
                    <div class="event-description">${description}</div>
                    
                    <div class="event-actions">
                        <button onclick="openReservationModal(${id}, '${title.replace(/'/g, "\\'")}');" class="action-button primary-button">🎟️ Participer</button>
                        <a href="front.php" class="action-button secondary-button">🔍 Voir tous les événements</a>
                    </div>
                `;
                
                eventDetails.innerHTML = html;
                document.getElementById('eventModal').style.display = 'block';
            }
        });
        
        function closeEventModal() {
            document.getElementById('eventModal').style.display = 'none';
        }
        
        function openReservationModal(eventId, eventTitle) {
            document.getElementById('eventModal').style.display = 'none';
            document.getElementById('reservationModal').style.display = 'block';
            document.getElementById('evenement_id').value = eventId;
            document.querySelector('.event-modal-content h2').textContent = 
                'Réserver pour : ' + eventTitle;
            
            // Set the date input format and default value
            configureDateInput();
        }
        
        function configureDateInput() {
            const dateInput = document.getElementById('date');
            
            // Set a placeholder for date format
            dateInput.placeholder = 'AAAA-MM-JJ';
            
            // Set the default value to today's date
            const today = new Date();
            const year = today.getFullYear();
            let month = today.getMonth() + 1;
            let day = today.getDate();
            
            // Format with leading zeros
            month = month < 10 ? '0' + month : month;
            day = day < 10 ? '0' + day : day;
            
            // Set the value
            dateInput.value = `${year}-${month}-${day}`;
        }
        
        function validateDateFormat(input) {
            // Check if the format is YYYY-MM-DD
            const datePattern = /^\d{4}-\d{2}-\d{2}$/;
            
            if (!datePattern.test(input.value)) {
                document.getElementById('date-error').textContent = 'Format de date incorrect. Utilisez le format AAAA-MM-JJ';
                input.classList.add('error');
                return false;
            }
            
            // Check if it's a valid date
            const date = new Date(input.value);
            if (isNaN(date.getTime())) {
                document.getElementById('date-error').textContent = 'Date invalide';
                input.classList.add('error');
                return false;
            }
            
            // Check if the date is not in the past
            const today = new Date();
            today.setHours(0, 0, 0, 0); // Reset time to beginning of day
            
            if (date < today) {
                document.getElementById('date-error').textContent = 'La date ne peut pas être dans le passé';
                input.classList.add('error');
                return false;
            }
            
            // Clear any error message
            document.getElementById('date-error').textContent = '';
            input.classList.remove('error');
            return true;
        }

        function closeReservationModal() {
            document.getElementById('reservationModal').style.display = 'none';
            document.getElementById('reservationForm').reset();
            document.getElementById('reservationMessage').innerHTML = '';
            
            // Clear error messages
            const errorSpans = document.querySelectorAll('.error-message');
            errorSpans.forEach(span => span.textContent = '');
            
            // Remove error classes
            const formInputs = document.querySelectorAll('.form-group input, .form-group textarea');
            formInputs.forEach(input => input.classList.remove('error'));
        }
        
        function validateForm(form) {
            let isValid = true;
            const errorMessages = {
                fullname: 'Veuillez entrer votre nom complet',
                email: 'Veuillez entrer une adresse email valide',
                date: 'Veuillez sélectionner une date',
                participants: 'Veuillez entrer un nombre de participants valide (minimum 1)'
            };
            
            // Reset errors
            const errorSpans = document.querySelectorAll('.error-message');
            errorSpans.forEach(span => span.textContent = '');
            
            const formInputs = document.querySelectorAll('.form-group input, .form-group textarea');
            formInputs.forEach(input => input.classList.remove('error'));
            
            // Check fullname (not empty)
            if (!form.fullname.value.trim()) {
                document.getElementById('fullname-error').textContent = errorMessages.fullname;
                form.fullname.classList.add('error');
                isValid = false;
            }
            
            // Check email (not empty and valid format)
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!form.email.value.trim() || !emailPattern.test(form.email.value.trim())) {
                document.getElementById('email-error').textContent = errorMessages.email;
                form.email.classList.add('error');
                isValid = false;
            }
            
            // Check date (not empty)
            if (!form.date.value.trim()) {
                document.getElementById('date-error').textContent = errorMessages.date;
                form.date.classList.add('error');
                isValid = false;
            } else {
                // Check if date is not in the past
                const selectedDate = new Date(form.date.value);
                const today = new Date();
                today.setHours(0, 0, 0, 0); // Reset time to beginning of day
                
                if (selectedDate < today) {
                    document.getElementById('date-error').textContent = 'La date ne peut pas être dans le passé';
                    form.date.classList.add('error');
                    isValid = false;
                }
            }
            
            // Check participants (not empty and at least 1)
            if (!form.participants.value.trim() || isNaN(form.participants.value) || parseInt(form.participants.value) < 1) {
                document.getElementById('participants-error').textContent = errorMessages.participants;
                form.participants.classList.add('error');
                isValid = false;
            }
            
            return isValid;
        }

        async function submitReservation(event) {
            event.preventDefault();
            const form = event.target;
            const messageDiv = document.getElementById('reservationMessage');
            
            // Validate form
            if (!validateForm(form)) {
                return; // Stop if validation fails
            }
            
            // Show loading state
            messageDiv.innerHTML = `
                <div style="text-align: center; padding: 10px; color: #666;">
                    <p>Envoi de la réservation en cours...</p>
                </div>`;

            try {
                const formData = {
                    evenement_id: parseInt(form.evenement_id.value),
                    fullname: form.fullname.value.trim(),
                    email: form.email.value.trim(),
                    date: form.date.value.trim(),
                    participants: parseInt(form.participants.value.trim()),
                    allergies: form.allergies.value.trim() || ''
                };

                const response = await fetch('../../controller/ReservationC.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(formData)
                });

                const result = await response.json();

                if (result.status === 'success') {
                    let message = `✅ ${result.message}`;
                    
                    // Add information about email status
                    if (result.email_sent) {
                        message += `<br><br>📧 Un email de confirmation a été envoyé à ${formData.email}`;
                    } else {
                        message += `<br><br>⚠️ Nous n'avons pas pu envoyer d'email de confirmation.`;
                    }
                    
                    messageDiv.innerHTML = `
                        <div class="success-message" style="padding: 15px; background: #e8f5e9; border-left: 4px solid #2e7d32; margin-top: 15px;">
                            ${message}
                        </div>`;
                    
                    // Disable the submit button to prevent double submissions
                    form.querySelector('button[type="submit"]').disabled = true;
                    
                    setTimeout(() => {
                        closeReservationModal();
                    }, 5000); // Give more time to read the message
                } else {
                    throw new Error(result.message);
                }
            } catch (error) {
                messageDiv.innerHTML = `
                    <div class="error-message" style="padding: 15px; background: #ffebee; border-left: 4px solid #c62828; margin-top: 15px;">
                        ❌ ${error.message || 'Une erreur est survenue lors de la réservation'}
                    </div>`;
            }
        }

        // Function to validate fullname field
        function validateFullname(input) {
            const value = input.value.trim();
            
            if (!value) {
                document.getElementById('fullname-error').textContent = 'Veuillez entrer votre nom complet';
                input.classList.add('error');
                return false;
            }
            
            // Clear any error message
            document.getElementById('fullname-error').textContent = '';
            input.classList.remove('error');
            return true;
        }
        
        // Function to validate email field
        function validateEmail(input) {
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            const value = input.value.trim();
            
            if (!value || !emailPattern.test(value)) {
                document.getElementById('email-error').textContent = 'Veuillez entrer une adresse email valide';
                input.classList.add('error');
                return false;
            }
            
            // Clear any error message
            document.getElementById('email-error').textContent = '';
            input.classList.remove('error');
            return true;
        }
        
        // Function to validate participants field
        function validateParticipants(input) {
            // Check if the value is a number and greater than 0
            const value = input.value.trim();
            
            if (!value || isNaN(value) || parseInt(value) < 1) {
                document.getElementById('participants-error').textContent = 'Veuillez entrer un nombre de participants valide (minimum 1)';
                input.classList.add('error');
                return false;
            }
            
            // Clear any error message
            document.getElementById('participants-error').textContent = '';
            input.classList.remove('error');
            return true;
        }

        // Close modals when clicking outside
        window.onclick = function(event) {
            const eventModal = document.getElementById('eventModal');
            const reservationModal = document.getElementById('reservationModal');
            
            if (event.target === eventModal) {
                closeEventModal();
            }
            
            if (event.target === reservationModal) {
                closeReservationModal();
            }
        }
    </script>
</body>
</html> 