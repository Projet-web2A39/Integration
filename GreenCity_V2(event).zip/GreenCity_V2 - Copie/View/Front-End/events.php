<?php
session_start();
require "../../config_db.php";

$database = new Database();
$conn = $database->getConnection();

$IdCurrentUser = $_SESSION['IdCurrentUser'] ?? null;
$userInfo = null;

if (isset($IdCurrentUser)) {
    try {
        $userInfo = $conn
            ->prepare("SELECT Nom, Prenom, Role, Img FROM user WHERE Id = :id");
        $userInfo->execute([':id' => $IdCurrentUser]);
        $userInfo = $userInfo->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        die("Erreur lors de la récupération des données utilisateur : " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Green City - Événements</title>
    <link rel="stylesheet" href="interface.css">
    <link rel="stylesheet" href="style.css">
    <link rel="icon" href="../../icon.png" type="image/png">
    <style>
        .event-section {
            margin: 50px auto;
             margin-top:10%;
            padding: 0 20px;
        }

        .section-title {
            text-align: center;
            color: #2e7d32;
            font-size: 2rem;
            margin-bottom: 40px;
        }


        .event-card {
            display:inline-block;
            margin:2%;
            width: 100%;
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .event-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 18px rgba(0, 0, 0, 0.15);
        }

        .event-image {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }

        .event-content {
            padding: 20px;
        }

        .event-title {
            font-size: 1.4rem;
            color: #2e7d32;
            margin-bottom: 10px;
        }

        .event-description {
            color: #555;
            margin-bottom: 15px;
            line-height: 1.5;
        }

        .event-details {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 20px;
            font-size: 0.9rem;
            color: #666;
        }

        .event-detail {
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .event-actions {
            display: flex;
            gap: 10px;
        }

        .action-button {
            padding: 8px 16px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 500;
            text-decoration: none;
            transition: background-color 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }

        .primary-button {
            background-color: #2e7d32;
            color: white;
        }

        .primary-button:hover {
            background-color: #1b5e20;
        }

        .secondary-button {
            background-color: #f5f5f5;
            color: #2e7d32;
        }

        .secondary-button:hover {
            background-color: #e0e0e0;
        }

        /* Responsive Design */
        

        @media (max-width: 768px) {
            .event-card {
                width: 100%;
            }
        }

        /* Ajout des styles pour le modal de réservation */
        .reservation-modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
        }

        .reservation-modal-content {
            background-color: #fff;
            margin: 5% auto;
            padding: 30px;
            width: 90%;
            max-width: 600px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
            position: relative;
        }

        .close-modal {
            position: absolute;
            right: 20px;
            top: 15px;
            font-size: 24px;
            cursor: pointer;
            color: #666;
            transition: color 0.3s ease;
        }

        .close-modal:hover {
            color: #000;
        }

        .reservation-form {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        
        .modal-header {
            border-bottom: 2px solid #e8f5e9;
            padding-bottom: 15px;
            margin-bottom: 20px;
            position: relative;
        }
        
        .modal-header h2 {
            color: #2e7d32;
            font-size: 1.8rem;
            margin: 0;
        }
        
        .modal-header::after {
            content: "";
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 60px;
            height: 4px;
            background-color: #2e7d32;
            border-radius: 2px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .form-group label {
            font-weight: 500;
            color: #2c3e50;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .form-group label .label-icon {
            color: #2e7d32;
            font-size: 1.2rem;
        }

        .form-group input,
        .form-group textarea {
            padding: 14px;
            border: 1px solid #dce4ec;
            border-radius: 8px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background-color: #f9f9f9;
        }

        .form-group input:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #2e7d32;
            box-shadow: 0 0 0 3px rgba(46, 125, 50, 0.1);
            background-color: #fff;
        }
        
        .form-group input:hover,
        .form-group textarea:hover {
            border-color: #aaa;
            background-color: #f5f5f5;
        }

        .error-message {
            color: #e74c3c;
            font-size: 0.85rem;
            margin-top: 5px;
            display: block;
        }

        .success-message {
            color: #2e7d32;
            font-size: 0.9rem;
            margin-top: 5px;
        }
        
        .submit-btn {
            padding: 14px;
            border: none;
            border-radius: 8px;
            background-color: #2e7d32;
            color: white;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
            width: 100%;
            margin-top: 10px;
        }
        
        .submit-btn:hover {
            background-color: #1b5e20;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        
        .submit-btn:active {
            transform: translateY(0);
        }
        
        .submit-btn:disabled {
            background-color: #a5d6a7;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }
        
        .required-field {
            color: #e74c3c;
            margin-left: 4px;
        }

        input.error, textarea.error {
            border-color: #e74c3c;
        }
    </style>
</head>
<body>
    <header style="margin-bottom:5%">
        <img src="../../Ressources/logo_GreenCity_trans.png" width="20%" alt="" id="logo_header">
        <nav>
            <a href="interface.php">Home</a>
            <a href="events.php" class="active">Events</a>
            <a href="forum.php">Forum</a>
            <a href="defi.php">Challenges</a>
            <a href="calendrier.php">Calendrier</a>
            <a href="../Back-End/dashboard.php">Dashboard</a>
        </nav>
        <a href="modify_profile.php" class="profile-link">
            <img src="../../<?= $userInfo['Img'] ?? 'Ressources/profile.png' ?>" alt="Profile Icon" class="profile-icon">
            <h2> <?= $userInfo['Prenom'] . " " . $userInfo['Nom'] ?></h2>
        </a>
        <form action="" method="post">
            <input type="submit" name="deconnexion" id="deconnexion" value="Deconnexion" style="float:right;color:#123A2D;background-color:#B5FFC1;width:110px ;padding:0.5%;border-radius:25px;border:none;margin-right:15px;font-size:15px">
        </form>
    </header>

    <section class="event-section">
        <h2 class="section-title">📅 Événements à venir</h2>
        <div class="event-grid">
            <?php
            require_once __DIR__ . '/../../controller/EvenementC.php';
            
            $controller = new EvenementController();
            $evenements = $controller->getAllEvenements();

            foreach ($evenements as $event) {
                echo '<div class="event-card">';
                
                // Use multiple path strategies for images
                $imagePath = $event->getImage();
                $imageBasename = !empty($imagePath) ? basename($imagePath) : '';
                
                // Try multiple possible paths for images
                $possiblePaths = [
                    $imagePath,                                           // Original path
                    '../../../' . ltrim($imagePath, '/'),                 // Path relative to this file
                    '/Haifa/phphaifa/uploads/events/' . $imageBasename,   // Absolute path from web root
                    '../Back-End/' . $imagePath,                          // Back-End relative path
                    '../../' . $imagePath                                 // Up two directories
                ];
                
                // Generate the image tag with multiple fallbacks
                $imgTag = '<img src="' . htmlspecialchars($possiblePaths[0]) . '" 
                    alt="' . htmlspecialchars($event->getTitre()) . '" 
                    class="event-image" 
                    onerror="
                        if (!this.dataset.tryCount) this.dataset.tryCount = 0;
                        const paths = ' . htmlspecialchars(json_encode($possiblePaths)) . ';
                        this.dataset.tryCount++;
                        if (this.dataset.tryCount < paths.length) {
                            this.src = paths[this.dataset.tryCount];
                        } else {
                            this.onerror = null;
                            this.src = \'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIyMDBweCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZTBlMGUwIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIyMCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iIGZpbGw9IiM2NjY2NjYiPkF1Y3VuZSBJbWFnZTwvdGV4dD48L3N2Zz4=\';
                        }
                    ">';
                
                if (!empty($imagePath)) {
                    echo $imgTag;
                } else {
                    echo '<div style="width:100%;height:200px;background:#e0e0e0;display:flex;align-items:center;justify-content:center;font-size:16px;color:#666;">Aucune Image</div>';
                }
                
                echo '<div class="event-content">';
                echo '<h3 class="event-title">' . htmlspecialchars($event->getTitre()) . '</h3>';
                echo '<p class="event-description">' . htmlspecialchars($event->getDescription()) . '</p>';
                echo '<div class="event-details">';
                echo '<span class="event-detail">📍 ' . htmlspecialchars($event->getType()) . '</span>';
                
                // Add date display if available
                if ($event->getDateE()) {
                    $formattedDate = date('d/m/Y', strtotime($event->getDateE()));
                    echo '<span class="event-detail">📅 ' . htmlspecialchars($formattedDate) . '</span>';
                }
                
                echo '</div>';
                echo '<div class="event-actions">';
                echo '<button onclick="openReservationModal(' . $event->getId() . ', \'' . htmlspecialchars($event->getTitre()) . '\')" class="action-button primary-button">🎟️ Participer</button>';
                echo '<a href="#" class="action-button secondary-button">ℹ️ Plus d\'infos</a>';
                echo '</div>';
                echo '</div>';
                echo '</div>';
            }
            ?>
        </div>
    </section>

    <!-- Ajout du modal de réservation -->
    <div id="reservationModal" class="reservation-modal">
        <div class="reservation-modal-content">
            <span class="close-modal" onclick="closeReservationModal()">&times;</span>
            <div class="modal-header">
                <h2>Réserver pour l'événement</h2>
            </div>
            <form id="reservationForm" class="reservation-form" onsubmit="submitReservation(event)">
                <input type="hidden" id="evenement_id" name="evenement_id">
                
                <div class="form-group">
                    <label for="fullname">
                        <span class="label-icon">👤</span>
                        Nom complet<span class="required-field">*</span>
                    </label>
                    <input id="fullname" name="fullname" placeholder="Entrez votre nom complet" onchange="validateFullname(this)">
                    <span class="error-message" id="fullname-error"></span>
                </div>

                <div class="form-group">
                    <label for="email">
                        <span class="label-icon">✉️</span>
                        Email<span class="required-field">*</span>
                    </label>
                    <input id="email" name="email" placeholder="Entrez votre adresse email" onchange="validateEmail(this)">
                    <span class="error-message" id="email-error"></span>
                </div>

                <div class="form-group">
                    <label for="date">
                        <span class="label-icon">📅</span>
                        Date<span class="required-field">*</span>
                    </label>
                    <input id="date" name="date" placeholder="AAAA-MM-JJ" onchange="validateDateFormat(this)">
                    <span class="error-message" id="date-error"></span>
                </div>

                <div class="form-group">
                    <label for="participants">
                        <span class="label-icon">👥</span>
                        Nombre de participants<span class="required-field">*</span>
                    </label>
                    <input id="participants" name="participants" placeholder="Nombre de personnes" onchange="validateParticipants(this)">
                    <span class="error-message" id="participants-error"></span>
                </div>

                <div class="form-group">
                    <label for="allergies">
                        <span class="label-icon">🩺</span>
                        Allergies ou besoins spéciaux
                    </label>
                    <textarea id="allergies" name="allergies" rows="3" placeholder="Si vous avez des allergies ou des besoins particuliers, veuillez les préciser ici"></textarea>
                </div>

                <button type="submit" class="submit-btn">
                    <span>🎟️</span> Confirmer la réservation
                </button>
            </form>
            <div id="reservationMessage"></div>
        </div>
    </div>

    <footer>
        <p>&copy; 2025 Green City - Horizon Digital | All Rights Reserved</p>
    </footer>

    <!-- Diagnostic Information (For Debugging) -->
    <?php if(isset($_GET['debug'])): ?>
    <div style="margin: 20px; padding: 15px; background: #f8f9fa; border: 1px solid #ddd; border-radius: 5px;">
        <h3>Diagnostic Information</h3>
        <p>Document Root: <?= htmlspecialchars($_SERVER['DOCUMENT_ROOT']) ?></p>
        <p>Script Path: <?= htmlspecialchars(__FILE__) ?></p>
        <p>Current URL: <?= htmlspecialchars($_SERVER['REQUEST_URI']) ?></p>
        
        <h4>Fix Images</h4>
        <div style="background:#f0f9ff; padding:10px; margin-bottom:15px; border-radius:5px;">
            <?php
            // Try to fix image paths by copying them from Back-End to Front-End if needed
            foreach($evenements as $idx => $evt) {
                $originalPath = $evt->getImage();
                $imageBasename = !empty($originalPath) ? basename($originalPath) : '';
                
                if (empty($imageBasename)) continue;
                
                // Check if the image is in the uploads directory
                $targetDir = $_SERVER['DOCUMENT_ROOT'] . '/Haifa/phphaifa/uploads/events/';
                $targetPath = $targetDir . $imageBasename;
                
                // Potential source path where images might actually be
                $backendPath = $_SERVER['DOCUMENT_ROOT'] . '/Haifa/phphaifa/view/Back-End/views/' . ltrim($originalPath, '/');
                $alternativePath = $_SERVER['DOCUMENT_ROOT'] . '/Haifa/' . ltrim($originalPath, '/');
                
                // Create target directory if it doesn't exist
                if (!is_dir($targetDir)) {
                    mkdir($targetDir, 0777, true);
                    echo "<p>Created directory: $targetDir</p>";
                }
                
                // If image exists at backend path, copy it to target
                if (file_exists($backendPath)) {
                    echo "<p>Image found at backend path: $backendPath</p>";
                    if (!file_exists($targetPath)) {
                        if (copy($backendPath, $targetPath)) {
                            echo "<p style='color:green'>Successfully copied image to: $targetPath</p>";
                        } else {
                            echo "<p style='color:red'>Failed to copy image to: $targetPath</p>";
                        }
                    } else {
                        echo "<p>Image already exists at target path: $targetPath</p>";
                    }
                } elseif (file_exists($alternativePath)) {
                    echo "<p>Image found at alternative path: $alternativePath</p>";
                    if (!file_exists($targetPath)) {
                        if (copy($alternativePath, $targetPath)) {
                            echo "<p style='color:green'>Successfully copied image to: $targetPath</p>";
                        } else {
                            echo "<p style='color:red'>Failed to copy image to: $targetPath</p>";
                        }
                    } else {
                        echo "<p>Image already exists at target path: $targetPath</p>";
                    }
                } else {
                    echo "<p style='color:orange'>Image not found at any path for event ID " . $evt->getId() . "</p>";
                    echo "<p>Checked paths:</p>";
                    echo "<ul>";
                    echo "<li>" . htmlspecialchars($originalPath) . "</li>";
                    echo "<li>" . htmlspecialchars($backendPath) . "</li>";
                    echo "<li>" . htmlspecialchars($alternativePath) . "</li>";
                    echo "</ul>";
                }
            }
            ?>
        </div>
        
        <h4>Image Paths:</h4>
        <ul>
        <?php foreach($evenements as $evt): ?>
            <?php 
            $img = $evt->getImage();
            $baseName = !empty($img) ? basename($img) : '';
            $alternativePath = '../../uploads/events/' . $baseName;
            $basenamePath = !empty($img) ? $baseName : '';
            ?>
            <li>
                <strong>Event: <?= htmlspecialchars($evt->getTitre()) ?> (ID: <?= $evt->getId() ?>)</strong><br>
                Stored Image Path: <?= htmlspecialchars($img) ?><br>
                Alternative Path: <?= htmlspecialchars($alternativePath) ?><br>
                Basename: <?= htmlspecialchars($basenamePath) ?><br>
                <div style="margin-top: 5px;">
                    Test direct path: <img src="<?= htmlspecialchars($img) ?>" height="30" onerror="this.nextElementSibling.textContent=' (Failed)';">
                    <span style="color:red;"></span>
                </div>
                <div style="margin-top: 5px;">
                    Test alternative path: <img src="<?= htmlspecialchars($alternativePath) ?>" height="30" onerror="this.nextElementSibling.textContent=' (Failed)';">
                    <span style="color:red;"></span>
                </div>
            </li>
        <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <script>
    function openReservationModal(eventId, eventTitle) {
        document.getElementById('reservationModal').style.display = 'block';
        document.getElementById('evenement_id').value = eventId;
        document.querySelector('.reservation-modal-content h2').textContent = 
            'Réserver pour : ' + eventTitle;
        
        // Set default date using JavaScript instead of HTML5 attributes
        configureDateInput();
    }
    
    function configureDateInput() {
        const dateInput = document.getElementById('date');
        
        // Set a placeholder for date format
        dateInput.placeholder = 'AAAA-MM-JJ';
        
        // Set the default value to today's date
        const today = new Date();
        const year = today.getFullYear();
        let month = today.getMonth() + 1;
        let day = today.getDate();
        
        // Format with leading zeros
        month = month < 10 ? '0' + month : month;
        day = day < 10 ? '0' + day : day;
        
        // Set the value
        dateInput.value = `${year}-${month}-${day}`;
    }
    
    function validateFullname(input) {
        const value = input.value.trim();
        
        if (!value) {
            document.getElementById('fullname-error').textContent = 'Veuillez entrer votre nom complet';
            input.classList.add('error');
            return false;
        }
        
        // Clear any error message
        document.getElementById('fullname-error').textContent = '';
        input.classList.remove('error');
        return true;
    }
    
    function validateEmail(input) {
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        const value = input.value.trim();
        
        if (!value || !emailPattern.test(value)) {
            document.getElementById('email-error').textContent = 'Veuillez entrer une adresse email valide';
            input.classList.add('error');
            return false;
        }
        
        // Clear any error message
        document.getElementById('email-error').textContent = '';
        input.classList.remove('error');
        return true;
    }
    
    function validateDateFormat(input) {
        // Check if the format is YYYY-MM-DD
        const datePattern = /^\d{4}-\d{2}-\d{2}$/;
        
        if (!datePattern.test(input.value)) {
            document.getElementById('date-error').textContent = 'Format de date incorrect. Utilisez le format AAAA-MM-JJ';
            input.classList.add('error');
            return false;
        }
        
        // Check if it's a valid date
        const date = new Date(input.value);
        if (isNaN(date.getTime())) {
            document.getElementById('date-error').textContent = 'Date invalide';
            input.classList.add('error');
            return false;
        }
        
        // Check if the date is not in the past
        const today = new Date();
        today.setHours(0, 0, 0, 0); // Reset time to beginning of day
        
        if (date < today) {
            document.getElementById('date-error').textContent = 'La date ne peut pas être dans le passé';
            input.classList.add('error');
            return false;
        }
        
        // Clear any error message
        document.getElementById('date-error').textContent = '';
        input.classList.remove('error');
        return true;
    }
    
    function validateParticipants(input) {
        // Check if the value is a number and greater than 0
        const value = input.value.trim();
        
        if (!value || isNaN(value) || parseInt(value) < 1) {
            document.getElementById('participants-error').textContent = 'Veuillez entrer un nombre de participants valide (minimum 1)';
            input.classList.add('error');
            return false;
        }
        
        // Clear any error message
        document.getElementById('participants-error').textContent = '';
        input.classList.remove('error');
        return true;
    }

    function closeReservationModal() {
        document.getElementById('reservationModal').style.display = 'none';
        document.getElementById('reservationForm').reset();
        document.getElementById('reservationMessage').innerHTML = '';
        
        // Clear error messages
        const errorSpans = document.querySelectorAll('.error-message');
        errorSpans.forEach(span => span.textContent = '');
        
        // Remove error classes
        const formInputs = document.querySelectorAll('.form-group input, .form-group textarea');
        formInputs.forEach(input => input.classList.remove('error'));
    }
    
    function validateForm(form) {
        let isValid = true;
        
        // Validate fullname
        if (!validateFullname(form.fullname)) {
            isValid = false;
        }
        
        // Validate email
        if (!validateEmail(form.email)) {
            isValid = false;
        }
        
        // Validate date
        if (!validateDateFormat(form.date)) {
            isValid = false;
        }
        
        // Validate participants
        if (!validateParticipants(form.participants)) {
            isValid = false;
        }
        
        return isValid;
    }

    async function submitReservation(event) {
        event.preventDefault();
        const form = event.target;
        const messageDiv = document.getElementById('reservationMessage');
        
        // Validate form
        if (!validateForm(form)) {
            return; // Stop if validation fails
        }
        
        // Show loading state
        messageDiv.innerHTML = `
            <div style="text-align: center; padding: 10px; color: #666;">
                <p>Envoi de la réservation en cours...</p>
            </div>`;

        try {
            const formData = {
                evenement_id: parseInt(form.evenement_id.value),
                fullname: form.fullname.value.trim(),
                email: form.email.value.trim(),
                date: form.date.value.trim(),
                participants: parseInt(form.participants.value.trim()),
                allergies: form.allergies.value.trim() || ''
            };

            const response = await fetch('../../controller/ReservationC.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });

            const result = await response.json();

            if (result.status === 'success') {
                let message = `✅ ${result.message}`;
                
                // Add information about email status
                if (result.email_sent) {
                    message += `<br><br>📧 Un email de confirmation a été envoyé à ${formData.email}`;
                } else {
                    message += `<br><br>⚠️ Nous n'avons pas pu envoyer d'email de confirmation.`;
                }
                
                messageDiv.innerHTML = `
                    <div class="success-message" style="padding: 15px; background: #e8f5e9; border-left: 4px solid #2e7d32; margin-top: 15px;">
                        ${message}
                    </div>`;
                
                // Disable the submit button to prevent double submissions
                form.querySelector('button[type="submit"]').disabled = true;
                
                setTimeout(() => {
                    closeReservationModal();
                }, 5000); // Give more time to read the message
            } else {
                throw new Error(result.message);
            }
        } catch (error) {
            messageDiv.innerHTML = `
                <div class="error-message" style="padding: 15px; background: #ffebee; border-left: 4px solid #c62828; margin-top: 15px;">
                    ❌ ${error.message || 'Une erreur est survenue lors de la réservation'}
                </div>`;
        }
    }

    // Fermer le modal si on clique en dehors
    window.onclick = function(event) {
        const modal = document.getElementById('reservationModal');
        if (event.target === modal) {
            closeReservationModal();
        }
    }
    </script>
</body>
</html>
