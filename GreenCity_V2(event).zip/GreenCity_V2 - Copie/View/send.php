<?php
// Include the SendGrid mail handler
require_once __DIR__ . '/../sendgrid-mail.php';

function send($to_email, $subject, $body) {
    // Call the SendGrid API function instead of using PHPMailer
    return sendWithSendGrid($to_email, $subject, $body);
}
?>
