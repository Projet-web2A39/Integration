<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/Config.php';

try {
    echo "Connecting to database...\n";
    $db = config::getConnexion();
    echo "Connected successfully.\n";
    
    // Check if the column already exists
    $checkQuery = "SHOW COLUMNS FROM evenement LIKE 'dateE'";
    echo "Executing query: $checkQuery\n";
    $checkStmt = $db->query($checkQuery);
    $columnExists = $checkStmt->rowCount() > 0;
    
    if (!$columnExists) {
        echo "Column 'dateE' does not exist. Adding it now...\n";
        // Add the dateE column
        $alterQuery = "ALTER TABLE evenement ADD COLUMN dateE DATE AFTER type";
        echo "Executing query: $alterQuery\n";
        $result = $db->exec($alterQuery);
        
        if ($result !== false) {
            echo "Success: The dateE column has been added to the evenement table.\n";
        } else {
            echo "Error: Failed to add the dateE column to the evenement table.\n";
            print_r($db->errorInfo());
        }
    } else {
        echo "The dateE column already exists in the evenement table.\n";
    }
} catch (PDOException $e) {
    echo "Database Error: " . $e->getMessage() . "\n";
    echo "Error code: " . $e->getCode() . "\n";
    echo "Stack trace: " . $e->getTraceAsString() . "\n";
}
?> 