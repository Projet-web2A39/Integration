<?php
// Check SendGrid API key permissions and account status

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// SendGrid API Key
const API_KEY = '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';

echo "<h1>SendGrid API Key Check</h1>";

// Check API key scopes
echo "<h2>Checking API Key Permissions</h2>";
$url = 'https://api.sendgrid.com/v3/scopes';
$headers = [
    'Authorization: Bearer ' . API_KEY,
    'Content-Type: application/json'
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);
curl_close($ch);

echo "<pre>";
echo "HTTP Code: $httpCode\n";

if ($error) {
    echo "cURL Error: $error\n";
}

echo "Response Body: \n";
if ($response) {
    $responseData = json_decode($response, true);
    echo json_encode($responseData, JSON_PRETTY_PRINT);
} else {
    echo "(Empty response)";
}
echo "</pre>";

// Try to send a very basic email with minimal content
echo "<h2>Attempting to Send a Minimal Email</h2>";
$url = 'https://api.sendgrid.com/v3/mail/send';
$data = [
    'personalizations' => [
        [
            'to' => [
                [
                    'email' => 'kasrfaset@gmail.com'
                ]
            ],
            'subject' => 'Minimal Test - ' . date('Y-m-d H:i:s')
        ]
    ],
    'from' => [
        'email' => 'kasrfaset@gmail.com'
    ],
    'content' => [
        [
            'type' => 'text/plain',
            'value' => 'This is a minimal test email with no formatting or additional content.'
        ]
    ]
];

$headers = [
    'Authorization: Bearer ' . API_KEY,
    'Content-Type: application/json'
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
curl_setopt($ch, CURLOPT_VERBOSE, true);

// Capture verbose output
$verbose = fopen('php://temp', 'w+');
curl_setopt($ch, CURLOPT_STDERR, $verbose);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);

// Get verbose information
rewind($verbose);
$verboseLog = stream_get_contents($verbose);

curl_close($ch);

echo "<pre>";
echo "HTTP Code: $httpCode\n";

if ($error) {
    echo "cURL Error: $error\n";
}

echo "Response Body: \n";
if ($response) {
    echo $response . "\n";
} else {
    echo "(Empty response - this is expected for successful requests)\n";
}

echo "\nVerbose Log: \n";
echo htmlspecialchars($verboseLog);
echo "</pre>";

// Provide conclusions and next steps
echo "<h2>Conclusions and Next Steps</h2>";
echo "<p>Based on the results above:</p>";
echo "<ol>";
echo "<li>If permission check failed (HTTP 401): Your API key may be invalid or restricted</li>";
echo "<li>If permission check succeeded but minimal email failed: There may be an issue with your sender verification</li>";
echo "<li>If both succeeded but emails aren't being delivered: They're likely being filtered as spam or SendGrid is throttling delivery</li>";
echo "</ol>";

echo "<h3>What to Do Next:</h3>";
echo "<ol>";
echo "<li><strong>Check the SendGrid Dashboard</strong> for any warnings or requirements for your account</li>";
echo "<li><strong>Complete Email Sender Authentication</strong> - This is crucial for delivery</li>";
echo "<li><strong>Try a different sender email</strong> - Some email providers need additional validation</li>";
echo "<li><strong>Check recipient spam folders</strong> - Especially important for Gmail accounts</li>";
echo "<li><strong>Consider creating a new API key</strong> with explicit Mail Send permissions</li>";
echo "</ol>";

echo "<p>More information: <a href='https://docs.sendgrid.com/ui/account-and-settings/api-keys' target='_blank'>SendGrid API Keys Documentation</a></p>";
?> 