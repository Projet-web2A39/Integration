<?php
// Browser-based image debug tool that simulates how images are loaded in the calendar

// Connect to database
require_once __DIR__ . '/Config.php';
$db = config::getConnexion();

// Process fixes if requested
$fixed = false;
if (isset($_GET['fix']) && $_GET['fix'] === '1') {
    // Create directory if it doesn't exist
    $uploads_dir = __DIR__ . '/uploads/events';
    if (!file_exists($uploads_dir)) {
        mkdir($uploads_dir, 0777, true);
    }
    
    // Get all events with image paths
    $sql = "SELECT id, titre, image FROM evenement WHERE image != ''";
    $stmt = $db->query($sql);
    $events = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $fixed_count = 0;
    
    foreach ($events as $event) {
        $original_path = $event['image'];
        $basename = basename($original_path);
        
        // Target path in uploads/events directory
        $target_path = $uploads_dir . '/' . $basename;
        $target_rel_path = 'uploads/events/' . $basename;
        
        // Skip if already in target location with correct path
        if ($original_path === $target_rel_path && file_exists($target_path)) {
            continue;
        }
        
        // Check if file already exists in target location
        if (file_exists($target_path)) {
            // Just update the database path
            $update_sql = "UPDATE evenement SET image = :image WHERE id = :id";
            $update_stmt = $db->prepare($update_sql);
            $update_stmt->execute([
                'image' => $target_rel_path,
                'id' => $event['id']
            ]);
            $fixed_count++;
            continue;
        }
        
        // Try to find and copy file
        $found = false;
        
        // First try original path
        if (file_exists($original_path)) {
            if (copy($original_path, $target_path)) {
                $found = true;
            }
        }
        
        // Try common locations
        if (!$found) {
            $possible_dirs = [
                __DIR__ . '/uploads/',
                dirname(__DIR__) . '/uploads/',
                'C:/xampp/htdocs/Haifa/uploads/',
                'C:/xampp/htdocs/Haifa/phphaifa/uploads/'
            ];
            
            foreach ($possible_dirs as $dir) {
                $test_path = $dir . $basename;
                if (file_exists($test_path)) {
                    if (copy($test_path, $target_path)) {
                        $found = true;
                        break;
                    }
                }
            }
        }
        
        // Update database if file was found and copied
        if ($found) {
            $update_sql = "UPDATE evenement SET image = :image WHERE id = :id";
            $update_stmt = $db->prepare($update_sql);
            $update_stmt->execute([
                'image' => $target_rel_path,
                'id' => $event['id']
            ]);
            $fixed_count++;
        }
    }
    
    $fixed = true;
    $fix_message = "Fixed $fixed_count image paths";
}

// Get all events with image paths
$sql = "SELECT id, titre, image, dateE FROM evenement WHERE image != ''";
$stmt = $db->query($sql);
$events = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get server info
$server_path = __DIR__;
$uploads_dir_exists = is_dir(__DIR__ . '/uploads/events');
$uploads_dir_writable = is_writable(__DIR__ . '/uploads/events');

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Browser Image Debug</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        h1, h2, h3 {
            color: #2e7d32;
        }
        
        .server-info {
            background-color: #f5f5f5;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .success {
            color: #2e7d32;
            font-weight: bold;
        }
        
        .error {
            color: #c62828;
            font-weight: bold;
        }
        
        .card {
            border: 1px solid #ddd;
            border-radius: 8px;
            margin-bottom: 20px;
            padding: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .image-test {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            grid-gap: 15px;
            margin-top: 15px;
        }
        
        .image-container {
            border: 1px solid #eee;
            border-radius: 5px;
            padding: 10px;
            position: relative;
        }
        
        .image-container img {
            max-width: 100%;
            height: 200px;
            object-fit: cover;
            display: block;
            margin: 0 auto;
            border-radius: 5px;
        }
        
        .path-label {
            margin-top: 10px;
            font-size: 12px;
            word-break: break-all;
            color: #666;
        }
        
        .status {
            position: absolute;
            top: 5px;
            right: 5px;
            padding: 3px 8px;
            border-radius: 3px;
            font-size: 12px;
            color: white;
        }
        
        .status.loaded {
            background-color: #2e7d32;
        }
        
        .status.failed {
            background-color: #c62828;
        }
        
        .fix-button {
            background-color: #2e7d32;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            text-decoration: none;
            display: inline-block;
            margin-bottom: 20px;
        }
        
        .fix-button:hover {
            background-color: #1b5e20;
        }
        
        .fix-message {
            background-color: #e8f5e9;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            border-left: 4px solid #2e7d32;
        }
    </style>
</head>
<body>
    <h1>Browser Image Debug Tool</h1>
    
    <?php if ($fixed): ?>
    <div class="fix-message">
        <strong><?= htmlspecialchars($fix_message) ?></strong>
    </div>
    <?php endif; ?>
    
    <a href="?fix=1" class="fix-button">🔧 Fix Images</a>
    
    <div class="server-info">
        <h2>Server Information</h2>
        <p><strong>Server Path:</strong> <?= htmlspecialchars($server_path) ?></p>
        <p><strong>Uploads Directory Exists:</strong> 
            <?= $uploads_dir_exists ? '<span class="success">Yes</span>' : '<span class="error">No</span>' ?>
        </p>
        <p><strong>Uploads Directory Writable:</strong> 
            <?= $uploads_dir_writable ? '<span class="success">Yes</span>' : '<span class="error">No</span>' ?>
        </p>
        <p><strong>Total Images in Database:</strong> <?= count($events) ?></p>
    </div>
    
    <h2>Image Tests</h2>
    <p>This page simulates how images are loaded in the calendar page. Each card shows an event and its image with different path strategies.</p>
    
    <?php foreach ($events as $event): ?>
    <div class="card">
        <h3><?= htmlspecialchars($event['titre']) ?> (ID: <?= $event['id'] ?>)</h3>
        <p><strong>Date:</strong> <?= $event['dateE'] ?? 'Not specified' ?></p>
        <p><strong>Original Path:</strong> <?= htmlspecialchars($event['image']) ?></p>
        
        <div class="image-test">
            <!-- Test 1: Original path -->
            <div class="image-container">
                <img src="<?= htmlspecialchars($event['image']) ?>" alt="Original path" 
                     onerror="this.parentNode.querySelector('.status').className = 'status failed'; this.parentNode.querySelector('.status').textContent = 'Failed'; this.style.display = 'none';"
                     onload="this.parentNode.querySelector('.status').className = 'status loaded'; this.parentNode.querySelector('.status').textContent = 'Loaded'">
                <div class="status">Testing...</div>
                <div class="path-label">Original: <?= htmlspecialchars($event['image']) ?></div>
            </div>
            
            <!-- Test 2: Standard path -->
            <?php $basename = basename($event['image']); ?>
            <div class="image-container">
                <img src="uploads/events/<?= htmlspecialchars($basename) ?>" alt="Standard path" 
                     onerror="this.parentNode.querySelector('.status').className = 'status failed'; this.parentNode.querySelector('.status').textContent = 'Failed'; this.style.display = 'none';"
                     onload="this.parentNode.querySelector('.status').className = 'status loaded'; this.parentNode.querySelector('.status').textContent = 'Loaded'">
                <div class="status">Testing...</div>
                <div class="path-label">Standard: uploads/events/<?= htmlspecialchars($basename) ?></div>
            </div>
            
            <!-- Test 3: Relative path -->
            <div class="image-container">
                <img src="/Haifa/phphaifa/uploads/events/<?= htmlspecialchars($basename) ?>" alt="Absolute path" 
                     onerror="this.parentNode.querySelector('.status').className = 'status failed'; this.parentNode.querySelector('.status').textContent = 'Failed'; this.style.display = 'none';"
                     onload="this.parentNode.querySelector('.status').className = 'status loaded'; this.parentNode.querySelector('.status').textContent = 'Loaded'">
                <div class="status">Testing...</div>
                <div class="path-label">Absolute: /Haifa/phphaifa/uploads/events/<?= htmlspecialchars($basename) ?></div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
    
    <a href="view/Front-End/calendrier.php" class="fix-button" style="background-color: #1976d2;">
        📅 Go to Calendar
    </a>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Count loaded and failed images
            const images = document.querySelectorAll('img');
            let loaded = 0;
            let failed = 0;
            
            images.forEach(img => {
                img.addEventListener('load', function() {
                    loaded++;
                    updateCounts();
                });
                
                img.addEventListener('error', function() {
                    failed++;
                    updateCounts();
                });
            });
            
            function updateCounts() {
                const summary = document.createElement('div');
                summary.className = 'server-info';
                summary.innerHTML = `
                    <h3>Image Load Summary</h3>
                    <p><strong>Loaded:</strong> <span class="success">${loaded}</span></p>
                    <p><strong>Failed:</strong> <span class="error">${failed}</span></p>
                    <p><strong>Total:</strong> ${images.length}</p>
                `;
                
                // Replace existing summary if it exists
                const existingSummary = document.querySelector('.image-summary');
                if (existingSummary) {
                    existingSummary.replaceWith(summary);
                } else if (loaded + failed >= images.length) {
                    // Add the summary at the end when all images have been processed
                    summary.className += ' image-summary';
                    document.querySelector('h2').after(summary);
                }
            }
        });
    </script>
</body>
</html> 