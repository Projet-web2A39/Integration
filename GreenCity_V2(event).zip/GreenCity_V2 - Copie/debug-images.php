<?php
// Simple Debug Tool for Image Paths

// Connect to database
require_once __DIR__ . '/Config.php';
$db = config::getConnexion();

// Get all events with image paths
$sql = "SELECT id, titre, image, dateE FROM evenement WHERE image != ''";
$stmt = $db->query($sql);
$events = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Define server variables
$document_root = $_SERVER['DOCUMENT_ROOT'];
$script_filename = dirname(__FILE__);
$base_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://" 
    . (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost');

// Define test paths
$test_dirs = [
    'uploads/events/',
    '../uploads/events/',
    '../../uploads/events/',
    '/uploads/events/',
    '/Haifa/phphaifa/uploads/events/',
    $script_filename . '/uploads/events/'
];

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Image Path Debug</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        table { border-collapse: collapse; width: 100%; margin-bottom: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        .error { color: red; }
        .success { color: green; }
        .image-preview { max-width: 150px; max-height: 150px; }
        .path-test { margin-bottom: 20px; padding: 10px; border: 1px solid #eee; }
    </style>
</head>
<body>
    <h1>Image Path Debug Tool</h1>
    
    <h2>Server Information</h2>
    <ul>
        <li><strong>Document Root:</strong> <?= htmlspecialchars($document_root) ?></li>
        <li><strong>Script Path:</strong> <?= htmlspecialchars($script_filename) ?></li>
        <li><strong>Base URL:</strong> <?= htmlspecialchars($base_url) ?></li>
    </ul>
    
    <h2>Directory Tests</h2>
    <table>
        <tr>
            <th>Path</th>
            <th>Exists</th>
            <th>Is Directory</th>
            <th>Is Readable</th>
        </tr>
        <?php foreach($test_dirs as $dir): ?>
        <tr>
            <td><?= htmlspecialchars($dir) ?></td>
            <td><?= file_exists($dir) ? '<span class="success">Yes</span>' : '<span class="error">No</span>' ?></td>
            <td><?= is_dir($dir) ? '<span class="success">Yes</span>' : '<span class="error">No</span>' ?></td>
            <td><?= is_readable($dir) ? '<span class="success">Yes</span>' : '<span class="error">No</span>' ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    
    <h2>Database Images (<?= count($events) ?> found)</h2>
    <?php if (empty($events)): ?>
        <p class="error">No images found in database</p>
    <?php else: ?>
        <table>
            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Date</th>
                <th>Image Path in DB</th>
                <th>File Exists</th>
            </tr>
            <?php foreach($events as $event): ?>
            <tr>
                <td><?= $event['id'] ?></td>
                <td><?= htmlspecialchars($event['titre']) ?></td>
                <td><?= $event['dateE'] ?? 'No date' ?></td>
                <td><?= htmlspecialchars($event['image']) ?></td>
                <td><?= file_exists($event['image']) ? '<span class="success">Yes</span>' : '<span class="error">No</span>' ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
        
        <h2>Image Path Tests</h2>
        <?php foreach($events as $event): 
            $basename = basename($event['image']);
        ?>
        <div class="path-test">
            <h3>Event: <?= htmlspecialchars($event['titre']) ?> (ID: <?= $event['id'] ?>)</h3>
            <p>Original path: <strong><?= htmlspecialchars($event['image']) ?></strong></p>
            <p>Basename: <strong><?= htmlspecialchars($basename) ?></strong></p>
            
            <table>
                <tr>
                    <th>Test Path</th>
                    <th>File Exists</th>
                    <th>Preview</th>
                </tr>
                
                <tr>
                    <td>Original: <?= htmlspecialchars($event['image']) ?></td>
                    <td><?= file_exists($event['image']) ? '<span class="success">Yes</span>' : '<span class="error">No</span>' ?></td>
                    <td><img src="<?= htmlspecialchars($event['image']) ?>" alt="Original" class="image-preview" onerror="this.style.display='none';"></td>
                </tr>
                
                <tr>
                    <td>uploads/events/<?= htmlspecialchars($basename) ?></td>
                    <td><?= file_exists('uploads/events/' . $basename) ? '<span class="success">Yes</span>' : '<span class="error">No</span>' ?></td>
                    <td><img src="uploads/events/<?= htmlspecialchars($basename) ?>" alt="Path 1" class="image-preview" onerror="this.style.display='none';"></td>
                </tr>
                
                <tr>
                    <td>/Haifa/phphaifa/uploads/events/<?= htmlspecialchars($basename) ?></td>
                    <td>--</td>
                    <td><img src="/Haifa/phphaifa/uploads/events/<?= htmlspecialchars($basename) ?>" alt="Path 2" class="image-preview" onerror="this.style.display='none';"></td>
                </tr>
                
                <tr>
                    <td>../../uploads/events/<?= htmlspecialchars($basename) ?></td>
                    <td><?= file_exists('../../uploads/events/' . $basename) ? '<span class="success">Yes</span>' : '<span class="error">No</span>' ?></td>
                    <td><img src="../../uploads/events/<?= htmlspecialchars($basename) ?>" alt="Path 3" class="image-preview" onerror="this.style.display='none';"></td>
                </tr>
            </table>
        </div>
        <?php endforeach; ?>
    <?php endif; ?>
    
    <script>
        // Add console logging for image load errors
        document.querySelectorAll('img').forEach(img => {
            img.addEventListener('error', function() {
                console.error('Image failed to load:', this.src);
            });
            
            img.addEventListener('load', function() {
                console.log('Image loaded successfully:', this.src);
                this.style.border = '2px solid green';
            });
        });
    </script>
</body>
</html> 