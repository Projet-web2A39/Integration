<?php
// Script to fix image paths by copying files to the uploads/events directory

// Connect to database
require_once __DIR__ . '/Config.php';
$db = config::getConnexion();

// Create directory if it doesn't exist
$uploads_dir = __DIR__ . '/uploads/events';
if (!file_exists($uploads_dir)) {
    mkdir($uploads_dir, 0777, true);
    echo "<p>Created directory: $uploads_dir</p>";
}

// Get all events with image paths
$sql = "SELECT id, titre, image FROM evenement WHERE image != ''";
$stmt = $db->query($sql);
$events = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "<h1>Image Path Fixer</h1>";
echo "<p>Found " . count($events) . " events with images</p>";

// Array of possible source directories
$possible_dirs = [
    __DIR__ . '/uploads/',
    dirname(__DIR__) . '/uploads/',
    dirname(dirname(__DIR__)) . '/uploads/',
    'C:/xampp/htdocs/Haifa/uploads/',
    'C:/xampp/htdocs/Haifa/phphaifa/uploads/'
];

$fixed_count = 0;

foreach ($events as $event) {
    echo "<h3>Processing: " . htmlspecialchars($event['titre']) . " (ID: {$event['id']})</h3>";
    
    $original_path = $event['image'];
    $basename = basename($original_path);
    
    echo "<p>Original path: " . htmlspecialchars($original_path) . "</p>";
    echo "<p>Basename: " . htmlspecialchars($basename) . "</p>";
    
    // Check if file exists in original path
    $file_exists = file_exists($original_path);
    echo "<p>Original file exists: " . ($file_exists ? 'Yes' : 'No') . "</p>";
    
    // Target path in uploads/events directory
    $target_path = $uploads_dir . '/' . $basename;
    $target_rel_path = 'uploads/events/' . $basename;
    
    // Already exists in target location?
    if (file_exists($target_path)) {
        echo "<p style='color:green;'>✅ File already exists in target location: $target_path</p>";
        
        // Update database if path is different
        if ($original_path != $target_rel_path) {
            $update_sql = "UPDATE evenement SET image = :image WHERE id = :id";
            $update_stmt = $db->prepare($update_sql);
            $update_stmt->execute([
                'image' => $target_rel_path,
                'id' => $event['id']
            ]);
            
            echo "<p style='color:blue;'>📝 Updated database record with new path: $target_rel_path</p>";
            $fixed_count++;
        }
        
        continue; // Skip to next event
    }
    
    // Try to find the file in possible locations
    $found = false;
    
    // First try the original path
    if ($file_exists) {
        // Copy file to target directory
        if (copy($original_path, $target_path)) {
            echo "<p style='color:green;'>✅ Copied file from original path to: $target_path</p>";
            $found = true;
        } else {
            echo "<p style='color:red;'>❌ Failed to copy from original path</p>";
        }
    }
    
    // If not found, try other possible locations
    if (!$found) {
        foreach ($possible_dirs as $dir) {
            $test_path = $dir . $basename;
            
            if (file_exists($test_path)) {
                echo "<p>Found file at: $test_path</p>";
                
                // Copy file to target directory
                if (copy($test_path, $target_path)) {
                    echo "<p style='color:green;'>✅ Copied file to: $target_path</p>";
                    $found = true;
                    break;
                } else {
                    echo "<p style='color:red;'>❌ Failed to copy from: $test_path</p>";
                }
            }
        }
    }
    
    // If still not found, check if we have files in uploads directory that could match
    if (!$found && is_dir(__DIR__ . '/uploads')) {
        $files = scandir(__DIR__ . '/uploads');
        foreach ($files as $file) {
            if ($file != '.' && $file != '..' && !is_dir(__DIR__ . '/uploads/' . $file)) {
                echo "<p>Found file in uploads: $file</p>";
                
                // Copy file to target directory
                if (copy(__DIR__ . '/uploads/' . $file, $target_path)) {
                    echo "<p style='color:green;'>✅ Copied alternate file to: $target_path</p>";
                    $found = true;
                    break;
                }
            }
        }
    }
    
    // Update database with new path
    if ($found) {
        $update_sql = "UPDATE evenement SET image = :image WHERE id = :id";
        $update_stmt = $db->prepare($update_sql);
        $update_stmt->execute([
            'image' => $target_rel_path,
            'id' => $event['id']
        ]);
        
        echo "<p style='color:blue;'>📝 Updated database record with new path: $target_rel_path</p>";
        $fixed_count++;
    } else {
        echo "<p style='color:red;'>❌ Could not find or copy the image file</p>";
    }
    
    echo "<hr>";
}

echo "<h2>Summary</h2>";
echo "<p>Fixed $fixed_count out of " . count($events) . " image paths</p>";
echo "<p><a href='debug-images.php'>Go to debug page</a></p>";
echo "<p><a href='view/Front-End/calendrier.php'>Go to calendar page</a></p>"; 