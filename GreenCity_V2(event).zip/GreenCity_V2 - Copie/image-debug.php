<?php
// Image Path Diagnostics Tool

header('Content-Type: text/html; charset=utf-8');

// Define directories to check
$directories = [
    'uploads/events/',
    '../uploads/events/',
    '../../uploads/events/',
    'phphaifa/uploads/events/',
    '/Haifa/phphaifa/uploads/events/',
    '/uploads/events/'
];

// Function to check if a directory exists and is readable
function checkDirectory($path) {
    $fullPath = realpath($path);
    $readable = is_readable($path);
    $exists = file_exists($path);
    $isDir = is_dir($path);
    
    return [
        'path' => $path,
        'fullPath' => $fullPath ? $fullPath : 'N/A',
        'exists' => $exists ? 'Yes' : 'No',
        'isDirectory' => $isDir ? 'Yes' : 'No',
        'readable' => $readable ? 'Yes' : 'No',
        'status' => ($exists && $isDir && $readable) ? 'OK' : 'Problem'
    ];
}

// Check database for image entries
$dbResults = [];
try {
    require_once __DIR__ . '/Config.php';
    $db = config::getConnexion();
    
    $sql = "SELECT id, titre, image FROM evenement WHERE image != '' LIMIT 10";
    $stmt = $db->query($sql);
    $dbResults = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $dbResults = ['error' => 'Failed to connect to database: ' . $e->getMessage()];
}

// Get current script URL
$baseUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
$scriptPath = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
$baseUrl .= $scriptPath;

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image Path Diagnostic Tool</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        h1, h2 {
            color: #2e7d32;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }
        
        th {
            background-color: #f2f2f2;
        }
        
        .problem {
            color: #d32f2f;
            font-weight: bold;
        }
        
        .ok {
            color: #2e7d32;
        }
        
        .image-test {
            margin-bottom: 30px;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        
        .image-test img {
            max-width: 200px;
            max-height: 200px;
            border: 1px solid #eee;
        }
        
        .server-info {
            background-color: #f9f9f9;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <h1>Image Path Diagnostic Tool</h1>
    
    <div class="server-info">
        <h2>Server Information</h2>
        <p><strong>Document Root:</strong> <?= $_SERVER['DOCUMENT_ROOT'] ?></p>
        <p><strong>Script Path:</strong> <?= dirname($_SERVER['SCRIPT_FILENAME']) ?></p>
        <p><strong>Base URL:</strong> <?= $baseUrl ?></p>
    </div>
    
    <h2>Directory Checks</h2>
    <table>
        <thead>
            <tr>
                <th>Path</th>
                <th>Full Path</th>
                <th>Exists</th>
                <th>Is Directory</th>
                <th>Readable</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($directories as $dir) : 
                $result = checkDirectory($dir);
            ?>
            <tr>
                <td><?= htmlspecialchars($result['path']) ?></td>
                <td><?= htmlspecialchars($result['fullPath']) ?></td>
                <td><?= $result['exists'] ?></td>
                <td><?= $result['isDirectory'] ?></td>
                <td><?= $result['readable'] ?></td>
                <td class="<?= $result['status'] === 'OK' ? 'ok' : 'problem' ?>"><?= $result['status'] ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    
    <h2>Database Image Entries</h2>
    <?php if (isset($dbResults['error'])) : ?>
        <p class="problem"><?= htmlspecialchars($dbResults['error']) ?></p>
    <?php else : ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Image Path</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($dbResults)) : ?>
                <tr>
                    <td colspan="3">No image entries found in database</td>
                </tr>
                <?php else : ?>
                    <?php foreach ($dbResults as $event) : ?>
                    <tr>
                        <td><?= htmlspecialchars($event['id']) ?></td>
                        <td><?= htmlspecialchars($event['titre']) ?></td>
                        <td><?= htmlspecialchars($event['image']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
        
        <h2>Image Loading Tests</h2>
        <?php foreach ($dbResults as $event) : 
            if (empty($event['image'])) continue;
            
            // Extract basename
            $basename = basename($event['image']);
            
            // Create test paths
            $testPaths = [
                'Original' => $event['image'],
                'Basename Only' => $basename,
                'Relative uploads/events' => 'uploads/events/' . $basename,
                'Relative ../uploads/events' => '../uploads/events/' . $basename,
                'Relative ../../uploads/events' => '../../uploads/events/' . $basename,
                'Absolute /uploads/events' => '/uploads/events/' . $basename,
                'Full path /Haifa/phphaifa/uploads/events' => '/Haifa/phphaifa/uploads/events/' . $basename,
            ];
        ?>
        <div class="image-test">
            <h3>Testing image for: <?= htmlspecialchars($event['titre']) ?> (ID: <?= $event['id'] ?>)</h3>
            <table>
                <thead>
                    <tr>
                        <th>Path Type</th>
                        <th>Path</th>
                        <th>Image Preview</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($testPaths as $type => $path) : ?>
                    <tr>
                        <td><?= htmlspecialchars($type) ?></td>
                        <td><?= htmlspecialchars($path) ?></td>
                        <td>
                            <img src="<?= htmlspecialchars($path) ?>" alt="Test <?= $type ?>" 
                                 onerror="this.onerror=null; this.src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDBweCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZmZlYmVlIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxNCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iIGZpbGw9IiNjNjI4MjgiPkZhaWxlZCB0byBsb2FkPC90ZXh0Pjwvc3ZnPg==';">
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endforeach; ?>
    <?php endif; ?>
    
    <h2>Manual Image Test</h2>
    <p>Enter an image path to test if it loads correctly:</p>
    <form method="get">
        <input type="text" name="test_path" placeholder="Enter image path" style="width: 50%; padding: 8px;" 
               value="<?= isset($_GET['test_path']) ? htmlspecialchars($_GET['test_path']) : '' ?>">
        <button type="submit" style="padding: 8px 16px;">Test Path</button>
    </form>
    
    <?php if (isset($_GET['test_path']) && !empty($_GET['test_path'])) : 
        $testPath = $_GET['test_path'];
    ?>
    <div class="image-test">
        <h3>Testing custom path: <?= htmlspecialchars($testPath) ?></h3>
        <p>
            <img src="<?= htmlspecialchars($testPath) ?>" style="max-width: 300px; max-height: 300px;" 
                 onerror="this.onerror=null; this.src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIyMDBweCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZmZlYmVlIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIyMCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iIGZpbGw9IiNjNjI4MjgiPkZhaWxlZCB0byBsb2FkPC90ZXh0Pjwvc3ZnPg=='; console.log('Failed to load: <?= addslashes($testPath) ?>');">
            <br>
            <?php
            // Check if file exists on server
            $fileExists = file_exists($testPath);
            $isReadable = is_readable($testPath);
            ?>
            <strong>File exists on server:</strong> <?= $fileExists ? '<span class="ok">Yes</span>' : '<span class="problem">No</span>' ?><br>
            <strong>File is readable:</strong> <?= $isReadable ? '<span class="ok">Yes</span>' : '<span class="problem">No</span>' ?><br>
            <?php if ($fileExists): ?>
                <strong>Full server path:</strong> <?= realpath($testPath) ?><br>
                <strong>File size:</strong> <?= filesize($testPath) ?> bytes
            <?php endif; ?>
        </p>
    </div>
    <?php endif; ?>
    
    <script>
        // Add console logging for all image load errors
        document.querySelectorAll('img').forEach(img => {
            img.addEventListener('error', function() {
                console.error('Image failed to load:', this.src);
            });
        });
    </script>
</body>
</html> 