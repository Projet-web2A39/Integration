<?php
session_start();
include '../connect.php'; // Include the Database class

if (!isset($_SESSION['user_id'])) {
    error_log("Session user_id is NOT set on delivery page.");
    $_SESSION['response'] = ['message' => 'You must be logged in to complete the delivery process.'];
    header('Location: ../Views/login.php');
    exit();
} else {
    error_log("Session user_id on delivery page: " . $_SESSION['user_id']);
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Include PHPMailer classes
require '../phpmailer/src/Exception.php';
require '../phpmailer/src/PHPMailer.php';
require '../phpmailer/src/SMTP.php';

// Include TCPDF
require_once 'C:/xampp/htdocs/1projet/vendor/tecnickcom/tcpdf/tcpdf.php';

use app\models\DeliveryModel;
include('C:/xampp/htdocs/1projet/newaddina/Models/DeliveryModel.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if user is logged in
    if (!isset($_SESSION['user_id'])) {
        $_SESSION['response'] = ['message' => 'You must be logged in to complete the delivery process.'];
        header('Location: ../Views/login.php');
        exit();
    }

    // Retrieve user_id from session
    $user_id = $_SESSION['user_id']; // Retrieve the logged-in user's ID
    error_log("Session user_id: " . $_SESSION['user_id']); // Debugging

    // Retrieve and sanitize input data
    $email = trim($_POST['email']);
    $phone_number = trim($_POST['phone_number']);
    $address = trim($_POST['address']);
    $payment_method = trim($_POST['payment_method']);

    // Validate input
    if (empty($email) || empty($phone_number) || empty($address) || empty($payment_method)) {
        $_SESSION['response'] = ['message' => 'All fields are required.'];
        header('Location: ../Views/delivery.php');
        exit();
    }

    // Log input data for debugging
    error_log("Email: $email, Phone Number: $phone_number, Address: $address, Payment Method: $payment_method");

    // Create an instance of the Database class to get the connection
    $database = new Database();
    $conn = $database->connect(); // Get the PDO connection

    // Create an instance of the DeliveryModel
    $deliveryModel = new DeliveryModel($conn);

    try {
        // Retrieve cart items and total price
        $query = "SELECT product_name, price, quantity FROM cart";
        $stmt = $conn->query($query);
        $cartItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Calculate the total price
        $totalPrice = 0;
        $receiptDetails = "Your purchased items:\n";

        foreach ($cartItems as $item) {
            $productName = $item['product_name'];
            $price = $item['price'];
            $quantity = $item['quantity'];
            $itemTotal = $price * $quantity;
            $totalPrice += $itemTotal;
            $receiptDetails .= "Product: $productName, Quantity: $quantity, Unit Price: $price, Total: $itemTotal\n";
        }
        $receiptDetails .= "\nGrand Total: $totalPrice";

        // Generate a unique cart_id for this transaction
        $cart_id = uniqid("cart_");

        // Save delivery information in the livetransaction table
        if ($deliveryModel->saveDelivery($email, $phone_number, $address, $payment_method, $cart_id, $user_id)) {
            // Save the total to the history table
            $historyQuery = "INSERT INTO history (cart_id, total , user_id) VALUES (:cart_id, :total ,:user_id)";
            $historyStmt = $conn->prepare($historyQuery);
            $historyStmt->bindParam(':cart_id', $cart_id);
            $historyStmt->bindParam(':total', $totalPrice);
            $historyStmt->bindParam(':user_id', $user_id); // Bind user_id to the query
            $historyStmt->execute();

            // Delete all items from the cart table
            $deleteQuery = "DELETE FROM cart";
            $stmt = $conn->prepare($deleteQuery);
            $stmt->execute();

            // Clear the cart from the session
            unset($_SESSION['cart']);

            $pdf = new TCPDF();

            // Set document information
            $pdf->SetCreator('Your Store');
            $pdf->SetAuthor('Your Store');
            $pdf->SetTitle('Purchase Receipt');
            $pdf->SetSubject('Your Purchase Receipt');
            
            // Add a page
            $pdf->AddPage();
            
            // Set the logo
            $logoPath = $_SERVER['DOCUMENT_ROOT'] . '/newaddina/assets/imgs/furniture/logo/logo.png'; // Absolute path
            if (file_exists($logoPath)) {
                // Convert 100x100 pixels to millimeters (at 72 DPI)
                $logoWidthMM = (100 / 72) * 25.4; // Convert pixels to mm
                $logoHeightMM = (100 / 72) * 25.4; // Convert pixels to mm
            
                // Get the page width and height
                $pageWidth = $pdf->getPageWidth();
                $pageHeight = $pdf->getPageHeight();
            
                // Position the logo at the top-right corner with a margin of 5mm from the right edge
                $pdf->Image($logoPath, $pageWidth - $logoWidthMM - 5, 5, $logoWidthMM, $logoHeightMM); // 5mm margin from the right
            } else {
                error_log("Logo file not found: " . $logoPath);
            }
            
            
            
            
            
            
            // Add a title
            $pdf->SetFont('helvetica', 'B', 16);
            $pdf->Ln(20); // Add space below the logo
            $pdf->Cell(0, 10, 'Purchase Receipt', 0, 1, 'C');
            
            // Add a horizontal line
            $pdf->SetLineWidth(0.5);
            $pdf->Line(10, 40, 200, 40);
            
            // Add receipt details
            $pdf->Ln(10); // Add space below the line
            $pdf->SetFont('helvetica', '', 12);
            $pdf->MultiCell(0, 10, "AY SA7A SA7A NCHALLAH MABROUK 3LIK L3A9BA LEZHEZ", 0, 'L');
            
            // Add table headers
            $pdf->Ln(5);
            $pdf->SetFont('helvetica', 'B', 12);
            $pdf->Cell(80, 10, 'Product Name', 1, 0, 'C');
            $pdf->Cell(30, 10, 'Quantity', 1, 0, 'C');
            $pdf->Cell(40, 10, 'Unit Price', 1, 0, 'C');
            $pdf->Cell(40, 10, 'Total', 1, 1, 'C');
            
            // Add cart items
            $pdf->SetFont('helvetica', '', 12);
            foreach ($cartItems as $item) {
                $pdf->Cell(80, 10, $item['product_name'], 1, 0, 'L');
                $pdf->Cell(30, 10, $item['quantity'], 1, 0, 'C');
                $pdf->Cell(40, 10, number_format($item['price'], 2) . ' DT', 1, 0, 'R');
                $pdf->Cell(40, 10, number_format($item['price'] * $item['quantity'], 2) . ' DT', 1, 1, 'R');
            }
            
            // Add total price
            $pdf->SetFont('helvetica', 'B', 12);
            $pdf->Cell(150, 10, 'Grand Total', 1, 0, 'R');
            $pdf->Cell(40, 10, number_format($totalPrice, 2) . ' DT', 1, 1, 'R');
            
            // Add footer message
            $pdf->Ln(10);
            $pdf->SetFont('helvetica', '', 10);
            $pdf->MultiCell(0, 10, "If you have any questions about your order, please contact us at my insta seifberr.", 0, 'L');
            
            // Save the PDF to the file system
            $dir = __DIR__ . '/../receipts';
            if (!is_dir($dir)) {
                mkdir($dir, 0777, true); // Create the directory if it doesn't exist
            }
            
            $filePath = $dir . '/receipt_' . $cart_id . '.pdf';
            $pdf->Output($filePath, 'F'); // Save PDF to the file system
            
            // Include the SendGrid mail handler
            require_once __DIR__ . '/sendgrid-mail.php';

            try {
                // Send the receipt email with attachment using SendGrid API
                $emailBody = "Thank you for your purchase! Please find your receipt attached.";
                
                if (sendWithAttachment($email, "Your Purchase Receipt", $emailBody, $filePath)) {
                    $_SESSION['response'] = ['message' => 'Delivery information saved, cart cleared, and receipt sent successfully!'];
                } else {
                    $_SESSION['response'] = ['message' => 'Delivery saved, but email could not be sent.'];
                }
            } catch (Exception $e) {
                $_SESSION['response'] = ['message' => "Delivery saved, but email could not be sent: {$e->getMessage()}"];
            }

            // Redirect to the confirmation page
            header('Location: ../Views/confirmation.php');
            exit();
        } else {
            throw new Exception('Failed to save delivery information.');
        }
    } catch (Exception $e) {
        error_log("Error: " . $e->getMessage());
        $_SESSION['response'] = ['message' => 'Failed to complete the delivery process.'];
        header('Location: ../Views/delivery.php');
        exit();
    }
} else {
    header('Location: ../Views/delivery.php');
    exit();
}
?>
