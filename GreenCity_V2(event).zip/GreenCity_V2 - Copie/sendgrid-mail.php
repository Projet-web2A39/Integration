<?php
/**
 * SendGrid Direct API Mail Handler
 * This file uses SendGrid's API directly instead of SMTP via PHPMailer
 */

// SendGrid API Key
const API_KEY = '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';

/**
 * Send an email using SendGrid's API
 * 
 * @param string $to The recipient email address
 * @param string $subject The email subject
 * @param string $textContent The plain text content of the email
 * @param string $htmlContent The HTML content of the email
 * @param string $fromEmail The sender email address
 * @param string $fromName The sender name
 * @return array The API response
 */
function sendGridMail($to, $subject, $textContent, $htmlContent, $fromEmail = 'kasrfaset@gmail.com', $fromName = 'Green City') {
    $url = 'https://api.sendgrid.com/v3/mail/send';
    $data = [
        'personalizations' => [
            [
                'to' => [
                    [
                        'email' => $to
                    ]
                ],
                'subject' => $subject
            ]
        ],
        'from' => [
            'email' => $fromEmail,
            'name' => $fromName
        ],
        'content' => [
            [
                'type' => 'text/plain',
                'value' => $textContent
            ],
            [
                'type' => 'text/html',
                'value' => $htmlContent
            ]
        ]
    ];

    $headers = [
        'Authorization: Bearer ' . API_KEY,
        'Content-Type: application/json'
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    
    $response = curl_exec($ch);
    $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);

    return [
        'status' => $statusCode,
        'response' => $response,
        'error' => $error
    ];
}

/**
 * Send an email with attachments using SendGrid's API
 * 
 * @param string $to The recipient email address
 * @param string $subject The email subject
 * @param string $textContent The plain text content of the email
 * @param string $htmlContent The HTML content of the email
 * @param array $attachments Array of attachment file paths
 * @param string $fromEmail The sender email address
 * @param string $fromName The sender name
 * @return array The API response
 */
function sendGridMailWithAttachments($to, $subject, $textContent, $htmlContent, $attachments = [], $fromEmail = 'kasrfaset@gmail.com', $fromName = 'Green City') {
    $url = 'https://api.sendgrid.com/v3/mail/send';
    $data = [
        'personalizations' => [
            [
                'to' => [
                    [
                        'email' => $to
                    ]
                ],
                'subject' => $subject
            ]
        ],
        'from' => [
            'email' => $fromEmail,
            'name' => $fromName
        ],
        'content' => [
            [
                'type' => 'text/plain',
                'value' => $textContent
            ],
            [
                'type' => 'text/html',
                'value' => $htmlContent
            ]
        ]
    ];

    // Add attachments if any
    if (!empty($attachments)) {
        $data['attachments'] = [];
        
        foreach ($attachments as $filePath) {
            if (file_exists($filePath)) {
                $content = base64_encode(file_get_contents($filePath));
                $data['attachments'][] = [
                    'content' => $content,
                    'filename' => basename($filePath),
                    'type' => mime_content_type($filePath),
                    'disposition' => 'attachment'
                ];
            }
        }
    }

    $headers = [
        'Authorization: Bearer ' . API_KEY,
        'Content-Type: application/json'
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    
    $response = curl_exec($ch);
    $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);

    return [
        'status' => $statusCode,
        'response' => $response,
        'error' => $error
    ];
}

/**
 * Simplified function to match the original send() function signature
 */
function sendWithSendGrid($to_email, $subject, $body) {
    // Extract plain text from HTML
    $textContent = strip_tags($body);
    
    $result = sendGridMail($to_email, $subject, $textContent, $body);
    
    if ($result['status'] >= 200 && $result['status'] < 300) {
        return true;
    } else {
        error_log("SendGrid API error: " . json_encode($result));
        return false;
    }
}

/**
 * Send an email with attachment using SendGrid's API
 * 
 * @param string $to_email Recipient email address
 * @param string $subject Email subject
 * @param string $body Email body (HTML)
 * @param string $attachmentPath Path to the attachment file
 * @return bool Whether the email was sent successfully
 */
function sendWithAttachment($to_email, $subject, $body, $attachmentPath) {
    // Extract plain text from HTML
    $textContent = strip_tags($body);
    
    $result = sendGridMailWithAttachments(
        $to_email, 
        $subject, 
        $textContent, 
        $body, 
        [$attachmentPath]
    );
    
    if ($result['status'] >= 200 && $result['status'] < 300) {
        return true;
    } else {
        error_log("SendGrid API error: " . json_encode($result));
        return false;
    }
}
?> 