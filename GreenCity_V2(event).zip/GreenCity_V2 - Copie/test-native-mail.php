<?php
// Test using PHP's native mail function

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>PHP Native mail() Test</h1>";

// Set up email details
$to = "kasrfaset@gmail.com";
$subject = "Test Email from PHP mail() - " . date('Y-m-d H:i:s');
$message = "This is a test email sent using PHP's native mail() function.\n\n";
$message .= "Time: " . date('Y-m-d H:i:s') . "\n";
$message .= "Server: " . ($_SERVER['SERVER_NAME'] ?? 'Unknown');

// Set additional headers
$headers = "From: Green City <kasrfaset@gmail.com>\r\n";
$headers .= "Reply-To: kasrfaset@gmail.com\r\n";
$headers .= "X-Mailer: PHP/" . phpversion();

// Send the email
$success = mail($to, $subject, $message, $headers);

// Output result
echo "<pre>";
echo "To: $to\n";
echo "Subject: $subject\n";
echo "Result: " . ($success ? "Mail sent successfully" : "Failed to send mail") . "\n";
echo "</pre>";

// Try the second email address too
$to2 = "seif.hamrouni@esprit.tn";
$subject2 = "Test Email from PHP mail() - " . date('Y-m-d H:i:s');
$success2 = mail($to2, $subject2, $message, $headers);

echo "<pre>";
echo "To: $to2\n";
echo "Subject: $subject2\n";
echo "Result: " . ($success2 ? "Mail sent successfully" : "Failed to send mail") . "\n";
echo "</pre>";

// Provide suggested next steps
echo "<h2>Next Steps if This Test Works</h2>";
echo "<p>If PHP's native mail() function works but SendGrid doesn't, consider:</p>";
echo "<ol>";
echo "<li>Your SendGrid account may have sending restrictions</li>";
echo "<li>Check the \"Sender Authentication\" section in your SendGrid dashboard</li>";
echo "<li>Make sure your API key has full \"Mail Send\" permissions</li>";
echo "<li>Try creating a new API key with full permissions</li>";
echo "</ol>";

echo "<h2>SendGrid Specific Issues</h2>";
echo "<p>Common problems with new SendGrid accounts:</p>";
echo "<ol>";
echo "<li>Free accounts are limited to 100 emails per day</li>";
echo "<li>You must verify your sender identity</li>";
echo "<li>Gmail recipients might filter SendGrid emails as spam</li>";
echo "<li>If you're sending from a local server, some providers may block your IP</li>";
echo "</ol>";
?> 