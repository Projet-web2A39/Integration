<?php
// Extended debugging script for SendGrid issues

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include the SendGrid mail handler
require_once __DIR__ . '/sendgrid-mail.php';

echo "<h1>SendGrid Extended Debug Test</h1>";

// Test server capabilities
echo "<h2>Server Environment</h2>";
echo "<pre>";
echo "PHP Version: " . phpversion() . "\n";
echo "cURL Extension: " . (function_exists('curl_version') ? 'Enabled' : 'Disabled') . "\n";
if (function_exists('curl_version')) {
    $curl_info = curl_version();
    echo "cURL Version: " . $curl_info['version'] . "\n";
    echo "SSL Version: " . $curl_info['ssl_version'] . "\n";
}
echo "JSON Extension: " . (function_exists('json_encode') ? 'Enabled' : 'Disabled') . "\n";
echo "Base64 Functions: " . (function_exists('base64_encode') ? 'Enabled' : 'Disabled') . "\n";
echo "</pre>";

// Test internet connectivity
echo "<h2>Testing Internet Connectivity</h2>";
echo "<pre>";
$sendgrid_host = 'api.sendgrid.com';
$host_reachable = @fsockopen($sendgrid_host, 443, $errno, $errstr, 5);
if ($host_reachable) {
    echo "Connection to $sendgrid_host:443 successful\n";
    fclose($host_reachable);
} else {
    echo "Cannot connect to $sendgrid_host:443 - Error $errno: $errstr\n";
}
echo "</pre>";

// Check API key validity by sending to yourself
echo "<h2>API Key Check</h2>";
echo "<p>Sending a test email to verify API key validity...</p>";

// Test with both the original recipient and an alternate recipient
$recipients = [
    'kasrfaset@gmail.com',
    'seif.hamrouni@esprit.tn' // Add a second test email address
];

foreach ($recipients as $to_email) {
    $subject = 'SendGrid API Test - ' . date('Y-m-d H:i:s');
    $htmlBody = '
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background-color: #2e7d32; color: white; padding: 15px; text-align: center; }
            .content { padding: 20px; border: 1px solid #ddd; }
            .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #666; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>SendGrid Extended Debug Test</h1>
            </div>
            <div class="content">
                <p>This is a test email sent to ' . $to_email . '.</p>
                <p>If you received this email, it means your SendGrid API key is valid and working correctly.</p>
                <p>Time sent: ' . date('Y-m-d H:i:s') . '</p>
                <p>Server IP: ' . ($_SERVER['SERVER_ADDR'] ?? 'Unknown') . '</p>
            </div>
            <div class="footer">
                <p>© ' . date('Y') . ' Green City - All rights reserved</p>
            </div>
        </div>
    </body>
    </html>
    ';
    $textBody = strip_tags($htmlBody);
    
    echo "<h3>Sending to: $to_email</h3>";
    
    $url = 'https://api.sendgrid.com/v3/mail/send';
    $data = [
        'personalizations' => [
            [
                'to' => [
                    [
                        'email' => $to_email
                    ]
                ],
                'subject' => $subject
            ]
        ],
        'from' => [
            'email' => 'kasrfaset@gmail.com',
            'name' => 'Green City Testing'
        ],
        'content' => [
            [
                'type' => 'text/plain',
                'value' => $textBody
            ],
            [
                'type' => 'text/html',
                'value' => $htmlBody
            ]
        ]
    ];
    
    $headers = [
        'Authorization: Bearer ' . API_KEY,
        'Content-Type: application/json'
    ];
    
    // Execute request with detailed error checking
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true); 
    curl_setopt($ch, CURLOPT_VERBOSE, true);
    
    // Capture verbose output
    $verbose = fopen('php://temp', 'w+');
    curl_setopt($ch, CURLOPT_STDERR, $verbose);
    
    // Execute the request
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    $errorNo = curl_errno($ch);
    
    // Get verbose information
    rewind($verbose);
    $verboseLog = stream_get_contents($verbose);
    
    curl_close($ch);
    
    echo "<h4>Request Details:</h4>";
    echo "<pre>";
    echo "API Key: " . substr(API_KEY, 0, 10) . "..." . substr(API_KEY, -5) . "\n";
    echo "HTTP Code: " . $httpCode . "\n";
    
    if ($error) {
        echo "cURL Error ($errorNo): " . $error . "\n";
    }
    
    echo "Response Body: \n";
    if ($response) {
        echo $response . "\n";
    } else {
        echo "(Empty response - this is expected for successful requests)\n";
    }
    
    echo "\nVerbose Log: \n";
    echo htmlspecialchars($verboseLog) . "\n";
    echo "</pre>";
    
    if ($httpCode >= 200 && $httpCode < 300) {
        echo "<p style='color:green; font-weight:bold;'>✓ Email to $to_email was accepted by SendGrid API (HTTP Code: $httpCode)</p>";
    } else {
        echo "<p style='color:red; font-weight:bold;'>✗ Failed sending to $to_email (HTTP Code: $httpCode)</p>";
    }
    
    echo "<hr>";
}

// Provide extra guidance
echo "<h2>Troubleshooting Steps</h2>";
echo "<ol>";
echo "<li>Check your <strong>spam folder</strong> in both email accounts - SendGrid emails sometimes get filtered</li>";
echo "<li>Verify your SendGrid account is <strong>fully activated and not restricted</strong> (check the SendGrid dashboard)</li>";
echo "<li>If using a free SendGrid account, make sure you've <strong>completed all verification steps</strong> including domain authentication</li>";
echo "<li>Check if your <strong>sender email</strong> (kasrfaset@gmail.com) has been verified in SendGrid</li>";
echo "<li>Try adding an <strong>email with a different domain</strong> as a recipient (Gmail may be filtered differently than other providers)</li>";
echo "</ol>";

echo "<p><strong>Note:</strong> Even though the API returns a successful 202 code, emails might still not be delivered due to SendGrid account restrictions or spam filtering.</p>";
?> 