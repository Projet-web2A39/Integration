<?php
// Detailed test script for SendGrid API with debugging

// Enable error reporting for better troubleshooting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include the SendGrid mail handler
require_once __DIR__ . '/sendgrid-mail.php';

// Set the recipient email (this would typically come from a form)
$to_email = 'kasrfaset@gmail.com'; // Using your email as the test recipient

// Set up the email content
$subject = 'Debug Test Email from Green City';
$htmlBody = '
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background-color: #2e7d32; color: white; padding: 15px; text-align: center; }
        .content { padding: 20px; border: 1px solid #ddd; }
        .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #666; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Green City Debug Test Email</h1>
        </div>
        <div class="content">
            <p>This is a detailed debug test email sent using the SendGrid API.</p>
            <p>If you received this email, it means the integration was successful!</p>
            <p>Time sent: ' . date('Y-m-d H:i:s') . '</p>
        </div>
        <div class="footer">
            <p>© 2023 Green City - All rights reserved</p>
        </div>
    </div>
</body>
</html>
';
$textBody = strip_tags($htmlBody);

echo "<h1>SendGrid API Test</h1>";
echo "<p>Testing email sending with SendGrid API...</p>";

// Send the email with full debugging information
$url = 'https://api.sendgrid.com/v3/mail/send';
$data = [
    'personalizations' => [
        [
            'to' => [
                [
                    'email' => $to_email
                ]
            ],
            'subject' => $subject
        ]
    ],
    'from' => [
        'email' => 'kasrfaset@gmail.com',
        'name' => 'Green City Debug Test'
    ],
    'content' => [
        [
            'type' => 'text/plain',
            'value' => $textBody
        ],
        [
            'type' => 'text/html',
            'value' => $htmlBody
        ]
    ]
];

$headers = [
    'Authorization: Bearer ' . API_KEY,
    'Content-Type: application/json'
];

echo "<h2>Request Details:</h2>";
echo "<pre>";
echo "URL: $url\n";
echo "API Key Used: " . substr(API_KEY, 0, 10) . "..." . substr(API_KEY, -5) . "\n";
echo "Headers: \n";
print_r($headers);
echo "Data: \n";
print_r($data);
echo "</pre>";

echo "<h2>Executing Request...</h2>";

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
curl_setopt($ch, CURLINFO_HEADER_OUT, true); // Enable output of header info

// Execute the request
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$headerSent = curl_getinfo($ch, CURLINFO_HEADER_OUT);
$error = curl_error($ch);
$errorNo = curl_errno($ch);
curl_close($ch);

echo "<h2>Response:</h2>";
echo "<pre>";
echo "HTTP Code: $httpCode\n";
echo "Headers Sent: \n$headerSent\n";

if ($error) {
    echo "cURL Error ($errorNo): $error\n";
}

echo "Response Body: \n";
if ($response) {
    echo $response;
} else {
    echo "(Empty response - this is expected for successful requests)";
}
echo "</pre>";

echo "<h2>Result:</h2>";
if ($httpCode >= 200 && $httpCode < 300) {
    echo "<p style='color:green; font-weight:bold;'>SUCCESS! Email was sent successfully (HTTP Code: $httpCode).</p>";
    echo "<p>Check your inbox at $to_email for the test email.</p>";
} else {
    echo "<p style='color:red; font-weight:bold;'>ERROR: Failed to send email (HTTP Code: $httpCode).</p>";
    echo "<p>Check the response above for details on what went wrong.</p>";
}
?> 