<?php
// Test script for SendGrid API

// Include the SendGrid mail handler
require_once __DIR__ . '/sendgrid-mail.php';

// Set the recipient email (this would typically come from a form)
$to_email = 'kasrfaset@gmail.com'; // Using your email as the test recipient

// Set up the email content
$subject = 'Test Email from Green City';
$body = '
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background-color: #2e7d32; color: white; padding: 15px; text-align: center; }
        .content { padding: 20px; border: 1px solid #ddd; }
        .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #666; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Green City Test Email</h1>
        </div>
        <div class="content">
            <p>This is a test email sent using the SendGrid API.</p>
            <p>If you received this email, it means the integration was successful!</p>
        </div>
        <div class="footer">
            <p>© 2023 Green City - All rights reserved</p>
        </div>
    </div>
</body>
</html>
';

// Send the email
$result = sendWithSendGrid($to_email, $subject, $body);

// Output the result
if ($result) {
    echo "Success! Test email was sent successfully.";
} else {
    echo "Error: Failed to send test email. Check error logs for details.";
}

// If you want to view more detailed information about the API response, 
// you can modify the sendWithSendGrid function to return the actual API response
// and uncomment this section:
/*
$result = sendGridMail($to_email, $subject, strip_tags($body), $body);
echo "<pre>";
print_r($result);
echo "</pre>";
*/
?> 